package game.enums;

/**
 * Use this enum class to give `buff` or `debuff`.
 * It is also useful to give a `state` to abilities or actions that can be attached-detached.
 *
 * Created by:
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */
public enum Status {
    /**
     *  Status to identify that an object is immune to any attack.
     */
    IMMUNE,
    /**
     * Status to be considered hostile towards enemy (e.g., to be attacked by enemy)
     */
    HOSTILE,
    /**
     * Status to identify that an object is capturable.
     */
    CATCHABLE,
    /**
     * Status to identify that an object is feedable.
     */
    FEEDABLE,
    /**
     * Status to identify that an object is givable.
     */
    GIVEABLE,
    /**
     * Status to identify that an object can be placed on an Incubator.
     */
    HATCHABLE,
    /**
     * Status to identify that a Pokemon can evolve.
     */
    EVOLVING,
    /**
     * Status to identify that an Actor can be teleported to another map.
     */
    TELEPORTABLE,
    /**
     * Status to identify that an Actor can enter a building.
     */
    CANENTERBUILDING
}
