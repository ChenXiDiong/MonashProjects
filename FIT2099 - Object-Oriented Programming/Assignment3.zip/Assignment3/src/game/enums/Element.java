package game.enums;

/**
 * Enumeration of possible elements within the game.
 * Created by:
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */
public enum Element {
    /**
     * The Water element.
     */
    WATER("Water"),
    /**
     * The Fire element.
     */
    FIRE("Fire"),
    /**
     * The Grass element.
     */
    GRASS("Grass"),
    /**
     * The Dragon element
     */
    DRAGON("Dragon");
    /**
     * The label of an Element.
     */
    private final String label;

    /**
     * Constructor.
     *
     * @param label the label of the Element.
     */
    Element(String label){
        this.label = label;
    }

    /**
     * A printable description of the Element.
     *
     * @return the label text
     */
    @Override
    public String toString() {
        return label;
    }
}
