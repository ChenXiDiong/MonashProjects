package game.behaviours;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.GameMap;
import game.actions.CatchAction;
import game.actions.FeedFruitAction;
import game.items.Pokefruit;
import game.pokemon.Pokemon;
import game.tools.AffectionManager;

/**
 * The behaviour of capturing a Pokemon.
 * Created by:
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */
public class CatchPokemonBehaviour implements Behaviour{

  /**
   * The minimum AP for a Pokemon to have towards the Actor to be able to be captured.
   */
  private static final int CATCHABLE_AP = 50;

  /**
   * Gives an Catch Action to the Actor with the CatchPokemonBehaviour.
   *
   * @param actor the Actor acting
   * @param map the GameMap containing the Actor
   * @return a Catch Action to be performed.
   */
  @Override
  public Action getAction(Actor actor, GameMap map) {
    AffectionManager affectionManager = AffectionManager.getInstance();
    for (Exit exit : map.locationOf(actor).getExits()) {
      Actor currActor = exit.getDestination().getActor();
      if (currActor instanceof Pokemon && affectionManager.getAffectionPoint((Pokemon) currActor,actor) > CATCHABLE_AP) {
        return new CatchAction((Pokemon) currActor, exit.getName());
      }
    }
    return null;
  }
}
