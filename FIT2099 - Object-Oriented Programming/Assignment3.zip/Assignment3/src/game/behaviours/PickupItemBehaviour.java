package game.behaviours;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.items.PickUpItemAction;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.items.Pokefruit;

/**
 * The behaviour of picking up a Pokefruit on the ground.
 * Created by:
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */
public class PickupItemBehaviour implements Behaviour{

  /**
   * Gives an PickUpItem Action to the Actor with the PickUpItem Behaviour.
   *
   * @param actor the Actor acting
   * @param map the GameMap containing the Actor
   * @return a PickUpItem Action to be performed.
   */
  @Override
  public Action getAction(Actor actor, GameMap map) {
    Location curr_location = map.locationOf(actor);
    for (Item item : curr_location.getItems()){
      if(item instanceof Pokefruit){
        return new PickUpItemAction(item);
      }
    }
    return null;
  }
}
