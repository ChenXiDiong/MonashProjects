package game.behaviours;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.GameMap;
import game.actions.FeedFruitAction;
import game.enums.Status;
import game.items.Pokefruit;
import game.pokemon.Pokemon;

/**
 * The behaviour of feeding a Pokefruit to a Pokemon.
 * Created by:
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */
public class FeedFruitBehaviour implements Behaviour{

  /**
   * Gives a Feed Fruit Action to the Actor with the FeedFruitBehaviour.
   *
   * @param actor the Actor acting
   * @param map the GameMap containing the Actor
   * @return an Feed Fruit Action to be performed.
   */
  @Override
  public Action getAction(Actor actor, GameMap map) {
    if(actor.hasCapability(Status.FEEDABLE)) {
      for (Exit exit : map.locationOf(actor).getExits()) {
        Actor currActor = exit.getDestination().getActor();
        if (currActor instanceof Pokemon) {
          for (Item item : actor.getInventory()) {
            if (item instanceof Pokefruit) {
              return new FeedFruitAction((Pokemon) currActor, (Pokefruit) item, exit.getName());
            }
          }
        }
      }
    }
    return null;
  }
}
