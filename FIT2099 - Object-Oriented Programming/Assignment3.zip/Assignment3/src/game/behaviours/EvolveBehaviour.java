package game.behaviours;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.GameMap;
import game.actions.EvolveAction;
import game.pokemon.Pokemon;

/**
 * The behaviour of a Pokemon evolving itself.
 * Created by:
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */
public class EvolveBehaviour implements Behaviour {

  /**
   * The evolved version of the Pokemon.
   */
  private static Pokemon evolved;

  /**
   * Constructor.
   *
   * @param evolved the evolved version of the Pokemon.
   */
  public EvolveBehaviour(Pokemon evolved){
    this.evolved = evolved;
  }

  /**
   * Gives an Evolve Action to the Actor with the Evolve Behaviour.
   *
   * @param actor the Actor acting
   * @param map the GameMap containing the Actor
   * @return an Evolve Action to be performed.
   */
  @Override
  public Action getAction(Actor actor, GameMap map) {
    boolean isSurrounding = false;
    for(Exit exit: map.locationOf(actor).getExits()) {
      if (!exit.getDestination().containsAnActor()) {
        isSurrounding = false;
      } else {
        isSurrounding = true;
      }
    }
    if (!isSurrounding){
      return new EvolveAction(actor, evolved);
    }
    return null;}

}
