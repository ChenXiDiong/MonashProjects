package game;

import game.grounds.Crater;
import game.grounds.Dirt;
import game.grounds.Door;
import game.grounds.Floor;
import game.grounds.Hay;
import game.grounds.Incubator;
import game.grounds.Lava;
import game.grounds.Puddle;
import game.grounds.Tree;
import game.grounds.Wall;
import game.grounds.Waterfall;
import game.players.Goh;
import game.players.Player;
import game.trading.NurseJoy;
import game.time.TimePerceptionManager;
import java.util.Arrays;
import java.util.List;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.FancyGroundFactory;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.World;

/**
 * The main class to start the Pokemon game ( run this class ).
 * Created by: ( provided by the teaching team, modified by the group ).
 *
 * @author Riordan D. Alfredo
 * Modified by:
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */
public class Application {

    /**
     * Driver method.
     *
     * @param args list of arguments to be provided.
     */
    public static void main(String[] args) {

        // initialize the world :
        World world = new World(new Display());

        FancyGroundFactory groundFactory = new FancyGroundFactory(
            new Dirt(), new Wall(), new Floor(),
            new Tree(), new Hay(),
            new Crater(), new Lava(),
            new Waterfall(), new Puddle(),
            new Incubator());

        List<String> map = Arrays.asList(
            ".............................................^^^^^^^^^^^^^^",
            "...........,,,................................,T,..^^^^O^^^",
            ".....................................................^^^^^^",
            "........................................................^^^",
            "............................................,,...........^^",
            "..............................###...........,.............^",
            "..,,,...............,.........#.#..........................",
            "..,,,......~...............................................",
            "...~~~~~~~~................................................",
            "....~~~~~..................................................",
            "~~W~~~~.,............................,,,...................",
            "~~~~~~.,T,...........................,T,...................",
            "~~~~~~~~~............................,.....................");
        GameMap gameMap = new GameMap(groundFactory, map);
        world.addGameMap(gameMap);

        List<String> pokemonCenter = Arrays.asList(
            "##################",
            "#________________#",
            "#______....._____#",
            "#________________#",
            "#________________#",
            "########_._#######");
        GameMap pokemonCenterMap = new GameMap(groundFactory, pokemonCenter);
        world.addGameMap(pokemonCenterMap);


        //Add player - Ash
        Player ash =  Player.getInstance();
        world.addPlayer(ash, gameMap.at(32, 10));

        //Add NurseJoy
        NurseJoy nurseJoy = NurseJoy.getInstance();
        pokemonCenterMap.at(9, 2).addActor(nurseJoy);

        //Add Goh
        Goh goh = Goh.getInstance();
        gameMap.at(30, 9).addActor(goh);

        //Adding Doors to the maps
        gameMap.at(31, 6).setGround(new Door(pokemonCenterMap.at(9, 5), "Pokemon Center"));
        pokemonCenterMap.at(9, 5).setGround(new Door(gameMap.at(31, 6), "Pallet Town"));

        world.run();

    }
}
