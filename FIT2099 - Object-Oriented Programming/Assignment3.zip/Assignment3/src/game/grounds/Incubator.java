package game.grounds;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.HatchAction;
import game.enums.Element;
import game.enums.Status;
import game.items.Pokefruit;
import game.items.PokemonEgg;
import game.pokemon.Bulbasaur;
import game.pokemon.Pokemon;
import java.util.ArrayList;
import java.util.List;

/**
 * The Incubator ground.
 * Created by:
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */
public class Incubator extends Ground {

  /**
   * The display character of the Incubator.
   */
  private static final char INCUBATOR_DISPLAY_CHAR = 'X';
  /**
   * The location of the Incubator.
   */
  private static Location location = null;
  /**
   * The Pokemon Eggs currently hatching on the Incubator.
   */
  private ArrayList<PokemonEgg> pokemonEggs;
  /**
   * Constructor.
   */
  public Incubator() {
    super(INCUBATOR_DISPLAY_CHAR);
    this.pokemonEggs = new ArrayList<>();
  }

  /**
   * The Action that can be performed by the Actor standing near the Incubator.
   *
   * @param actor the Actor acting
   * @param location the current Location
   * @param direction the direction of the Ground from the Actor
   * @return a list of allowable actions.
   */
  @Override
  public ActionList allowableActions(Actor actor, Location location, String direction){
    ActionList actionList = new ActionList();
    if(actor.hasCapability(Status.HATCHABLE)){
      for(Item item : actor.getInventory()){
        if(item instanceof PokemonEgg) {
          actionList.add(new HatchAction(this.location, (PokemonEgg) item));
        }
      }
    }
    return actionList;
  }

  /**
   * Executes turn-based methods of the Incubator ground.
   *
   * @param location The location of the Incubator ground.
   */
  @Override
  public void tick(Location location) {
    this.location = location;
    List<PokemonEgg> pokemonEggsC = new ArrayList<PokemonEgg>();
    pokemonEggsC.addAll(this.pokemonEggs);
    for(PokemonEgg pokemonEgg:pokemonEggsC) {
      Pokemon pokemon = pokemonEgg.hatch();
      if (pokemon != null) {
        if (!this.location.containsAnActor()) {
          this.location.addActor(pokemon);
          this.location.removeItem(pokemonEgg);
          pokemonEggs.remove(pokemonEgg);
        } else {
          for (Exit exit : this.location.getExits()) {
            if (!exit.getDestination().containsAnActor()) {
              exit.getDestination().addActor(pokemon);
              this.location.removeItem(pokemonEgg);
              pokemonEggs.remove(pokemonEgg);
              break;
            }
          }
        }

      }
    }
  }
}
