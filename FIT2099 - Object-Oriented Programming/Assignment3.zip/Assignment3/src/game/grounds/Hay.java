package game.grounds;

import edu.monash.fit2099.engine.positions.Ground;
import game.enums.Element;

/**
 * The Hay ground.
 *
 * Created by:
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */
public class Hay extends Ground{

  /**
   * The display character of the Hay.
   */
  private static final char HAY_DISPLAY_CHAR = ',';

  /**
   * Constructor.
   */
  public Hay() {
    super(HAY_DISPLAY_CHAR);
    this.addCapability(Element.GRASS);
  }


}
