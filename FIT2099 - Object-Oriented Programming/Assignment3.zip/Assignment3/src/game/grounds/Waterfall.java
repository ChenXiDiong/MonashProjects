package game.grounds;

import edu.monash.fit2099.engine.positions.Location;
import game.enums.Element;
import game.items.Pokefruit;
import game.pokemon.Squirtle;

/**
 * The Waterfall ground.
 * Created by:
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */
public class Waterfall extends SpawningGround {

  /**
   * The display character of Waterfall.
   */
  private static final char WATERFALL_DISPLAY_CHAR = 'W';
  /**
   * The chance of spawning a Squirtle.
   */
  private static final double SQUIRTLE_SPAWN_CHANCE = 0.2;
  /**
   * The chance of dropping a Water Pokefruit.
   */
  private static final double WATER_POKEFRUIT_DROP_CHANCE = 0.2;
  /**
   * The minimum number of adjacent water element grounds for the Waterfall to be able to spawn a Squirtle.
   */
  private static final int NUMBER_WATER_ELEMENT = 2;

  /**
   * Constructor.
   *
   */
  public Waterfall() {
    super(WATERFALL_DISPLAY_CHAR);
    this.addCapability(Element.WATER);
  }

  /**
   * Executes turn-based methods of the Waterfall ground.
   *
   * @param location The location of the Waterfall ground.
   */
  @Override
  public void tick(Location location) {
    spawnPokemon(location, new Squirtle(), SQUIRTLE_SPAWN_CHANCE, Element.WATER, NUMBER_WATER_ELEMENT);
    dropPokeFruit(location, new Pokefruit(Element.WATER), WATER_POKEFRUIT_DROP_CHANCE);
  }
}
