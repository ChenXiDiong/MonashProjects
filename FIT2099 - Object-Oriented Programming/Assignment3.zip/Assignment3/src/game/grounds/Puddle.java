package game.grounds;

import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;
import game.enums.Element;
import game.tools.ElementsHelper;
import game.time.TimePerception;
import game.tools.Utils;

/**
 * The Puddle ground.
 * Created by:
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */
public class Puddle extends Ground implements TimePerception, SpreadingGround{

    /**
     * The display character of the Puddle.
     */
    private static final char PUDDLE_DISPLAY_CHAR = '~';
    /**
     * The chance of carrying out the day effect of Puddle.
     */
    private static final double PUDDLE_DAY_EFFECT = 0.1;
    /**
     * The chance of carrying out the night effect of Puddle.
     */
    private static final double PUDDLE_NIGHT_EFFECT = 0.1;
    /**
     * The location of the Puddle.
     */
    private Location location;
    /**
     * Constructor.
     */
    public Puddle() {
        super(PUDDLE_DISPLAY_CHAR);
        this.addCapability(Element.WATER);
        // add this instance to the relevant manager
        this.registerInstance();
    }

    /**
     * The day effect of the Puddle ground.
     */
    @Override
    public void dayEffect() {
        //Puddle ~ have a 10% chance of being destroyed (converted to a Dirt).
        if (this.location != null && Utils.generateRandomProbability() < PUDDLE_DAY_EFFECT){
            location.setGround(new Dirt());
        }
    }

    /**
     * The night effect of the Puddle ground.
     */
    @Override
    public void nightEffect() {
        //Puddle ~ has 10% chance to expand (convert its surrounding grounds to Puddle~).
        if (this.location != null && Utils.generateRandomProbability() < PUDDLE_NIGHT_EFFECT){
            spreadGround(location);
        }

    }

    /**
     * Changes the adjacent grounds to Puddle if the condition is met.
     *
     * @param location the location of the Puddle ground.
     */
    @Override
    public void spreadGround(Location location) {
        for(Exit exit : location.getExits()){
            //The expanding grounds won't convert the Floors, Walls, and grounds with similar elements
            if(!(exit.getDestination().getGround()instanceof Wall)
                    &&!(exit.getDestination().getGround()instanceof Floor)
                    && !(ElementsHelper.hasAnySimilarElements(location.getGround(),exit.getDestination().getGround().findCapabilitiesByType(Element.class)))){
                exit.getDestination().setGround(new Puddle());
            }
        }
    }

    /**
     * Executes turn-based methods of the Lava ground.
     *
     * @param location The location of the Lava ground.
     */
    @Override
    public void tick(Location location) {
        this.location = location;
    }
}
