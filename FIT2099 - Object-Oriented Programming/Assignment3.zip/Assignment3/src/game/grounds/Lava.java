package game.grounds;

import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;
import game.enums.Element;
import game.tools.ElementsHelper;
import game.time.TimePerception;
import game.tools.Utils;

/**
 * The Lava ground.
 *
 * Created by:
 * @author Riordan D. Alfredo
 * Modified by:
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */
public class Lava extends Ground implements TimePerception, SpreadingGround {

    /**
     * The display character of Lava.
     */
    private static final char LAVA_DISPLAY_CHAR = '^';
    /**
     * The chance of carrying out the day effect of Lava.
     */
    private static final double LAVA_DAY_EFFECT = 0.1;
    /**
     * The chance of carrying out the night effect of Lava.
     */
    private static final double LAVA_NIGHT_EFFECT = 0.1;
    /**
     * The location of the Lava ground.
     */
    private Location location;

    /**
     * Constructor.
     */
    public Lava() {
        super(LAVA_DISPLAY_CHAR);
        this.addCapability(Element.FIRE);

        // add this instance to the relevant manager
        this.registerInstance();
    }

    /**
     * The day effect of the Lava ground.
     */
    @Override
    public void dayEffect() {
        if (this.location != null && Utils.generateRandomProbability() < LAVA_DAY_EFFECT){
            spreadGround(location);
        }
    }

    /**
     * The night effect of the Lava ground.
     */
    @Override
    public void nightEffect() {
        //Lava ^ has a 10% chance of being destroyed (converted to a Dirt)
        // as long as there's no actor on it.
        if (this.location != null && Utils.generateRandomProbability() < LAVA_NIGHT_EFFECT && !location.containsAnActor()){
            location.setGround(new Dirt());
        }

    }

    /**
     * Changes the adjacent grounds to Lava if condition is met.
     *
     * @param location the location of the Lava ground.
     */
    @Override
    public void spreadGround(Location location) {
        for(Exit exit : location.getExits()){
            //The expanding grounds won't convert the Floors, Walls, and grounds with similar elements
            if(!(exit.getDestination().getGround() instanceof Wall)
                    &&!(exit.getDestination().getGround() instanceof Floor)
                    && !(ElementsHelper.hasAnySimilarElements(location.getGround(),exit.getDestination().getGround().findCapabilitiesByType(Element.class)))){
                exit.getDestination().setGround(new Lava());
            }
        }
    }

    /**
     * Executes turn-based methods of the Lava ground.
     *
     * @param location The location of the Lava ground.
     */
    @Override
    public void tick(Location location) {
        this.location = location;
    }
}
