package game.grounds;

import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;

/**
 * Interface of a Ground that is able to spread to other Grounds.
 *
 * Created by:
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */
public interface SpreadingGround {

    /**
     * Changes other grounds to the same Ground if conditions are met.
     *
     * @param location the location of the ground.
     */
    void spreadGround(Location location);
}
