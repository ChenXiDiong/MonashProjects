package game.grounds;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.HatchAction;
import game.actions.TeleportAction;
import game.enums.Status;
import game.players.Player;

/**
 * The Door ground.
 * Created by:
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */
public class Door extends Ground {

  /**
   * The display character of the Door ground.
   */
  private static final char DOOR_DISPLAY_CHAR = '=';
  /**
   * The destination that the Door will teleport the Actor to.
   */
  private final Location destination;
  /**
   * The name of the destination.
   */
  private final String destinationName;

  /**
   * Constructor.
   *
   * @param destination the destination that the Door will teleport the Actor to.
   * @param destinationName the name of the destination.
   */
  public Door(Location destination, String destinationName) {
    super(DOOR_DISPLAY_CHAR);
    this.destination = destination;
    this.destinationName = destinationName;
  }

  /**
   * The Action that can be performed by the Actor standing on the Door.
   *
   * @param actor the Actor acting
   * @param location the current Location
   * @param direction the direction of the Ground from the Actor
   * @return a list of allowable actions.
   */
  @Override
  public ActionList allowableActions(Actor actor, Location location, String direction){
    ActionList actionList = new ActionList();
    if(location.containsAnActor() && location.getActor().hasCapability(Status.TELEPORTABLE)){
      actionList.add(new TeleportAction(destination, destinationName));
    }
    return actionList;
  }

  /**
   * Checks whether the actor is able to stand on the Door.
   *
   * @param actor the Actor to check
   * @return true if the actor is the Player, false otherwise.
   */
  @Override
  public boolean canActorEnter(Actor actor) {
    if(actor.hasCapability(Status.CANENTERBUILDING)){
      return true;
    }
    return false;
  }
}
