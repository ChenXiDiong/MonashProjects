package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import game.tools.AffectionManager;
import game.enums.Status;
import game.behaviours.FollowBehaviour;
import game.items.Candy;
import game.items.Pokeball;
import game.pokemon.Pokemon;

/**
 * An Action to catch a Pokemon.
 * Created by:
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */

public class CatchAction extends Action {
  /**
   * The Pokemon that is to be captured
   */
  private Pokemon targetPokemon;
  /**
   * The direction of incoming attack.
   */
  private String direction;
  /**
   * The minimum Affection Point of a Pokemon for the Player to be able to catch it.
   */
  private static final int POINT_FAIL_CAPTURE = 50;
  /**
   * The minimum Affection Point of a Pokemon for it to follow the Player.
   */
  private static final int POINT_TO_FOLLOW = 75;
  /**
   * The Affection Point decreased for a Pokemon upon unsuccessful capture.
   */
  private static final int DECREASE_POINT = 10;

  /**
   * Constructor.
   *
   * @param targetPokemon the Pokemon to capture
   * @param direction the direction of the Pokemon
   */
  public CatchAction(Pokemon targetPokemon, String direction) {
    this.targetPokemon = targetPokemon;
    this.direction = direction;
  }

  /**
   * Execution of the Catch Action.
   *
   * @param actor The actor performing the action.
   * @param map The map the actor is on.
   * @return The result of the action (the capture fails/succeeds).
   */
  @Override
  public String execute(Actor actor, GameMap map) {
    AffectionManager affectionManager  = AffectionManager.getInstance();
    String result = actor + " try to capture " + targetPokemon;
    int points = affectionManager.getAffectionPoint(targetPokemon,actor);
    // AP < 50
    if (points < POINT_FAIL_CAPTURE){
      affectionManager.decreaseAffection(targetPokemon,actor,DECREASE_POINT);
      // if <-50, can't be captured anymore
      int post_capture_AP = affectionManager.getAffectionPoint(targetPokemon,actor);
      if (post_capture_AP<-50){
        targetPokemon.removeCapability(Status.CATCHABLE);
        targetPokemon.removeCapability(Status.FEEDABLE);
      }
      result+=", FAIL!";
      return result;
    }
    else{
      result += ", Succeed!";
      //******************* Logic here ****************************//
      if (points >= POINT_TO_FOLLOW) {
        //75: It will follow the trainer/player around.
        // add FollowBehavior into behaviours
        targetPokemon.addBehaviour(9,new FollowBehaviour(actor));
        result += ", pokemon will follow the player";
      // successful capture
      // it will store the corresponding Pokemon instance in this Pokeball
      Pokeball pokeball = new Pokeball(targetPokemon);
      actor.addItemToInventory(pokeball); // pokeball that contains a specific captured pokemon
      //A candy will drop after successfully capturing a Pokemon.
      map.locationOf(targetPokemon).addItem(new Candy());
      map.removeActor(targetPokemon);


      }
      // return statement :
      return result;
    }





  }

  /**
   * The description displayed in the menu showing the action performed.
   *
   * @param actor The actor performing the action.
   * @return An indication of the Catch Action being performed.
   */
  @Override
  public String menuDescription(Actor actor) {
    AffectionManager affectionManager = AffectionManager.getInstance();
    // description of the action (text) :
    return actor + " catches " + targetPokemon + " with AP: " + affectionManager.getAffectionPoint(targetPokemon, actor) + " to the " + direction;
  }

}
