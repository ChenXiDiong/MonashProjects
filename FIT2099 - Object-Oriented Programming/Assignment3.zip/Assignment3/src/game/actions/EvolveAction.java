package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.enums.Status;
import game.pokemon.Pokemon;
import game.tools.AffectionManager;

/**
 * An action to evolve a Pokemon.
 *
 * Created by:
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */
public class EvolveAction extends Action {

  /**
   * The AP of the Pokemon after a manual evolution.
   */
  public static final int EVOLVED_AP = 75;
  /**
   * The target pokemon to be evolved.
   */
  private Actor target;
  /**
   * The evolved version of the Pokemon.
   */
  private Pokemon evolved;

  /**
   * Constructor
   *
   * @param target the target Pokemon to be evolved.
   * @param evolved the evolved version of the Pokemon.
   */
  public EvolveAction(Actor target, Pokemon evolved){
    this.target = target;
    this.evolved = evolved;
  }

  /**
   * Execution of the Evolve Action.
   *
   * @param actor The actor performing the action.
   * @param map The map the actor is on.
   * @return An indication of whether the Pokemon evolved by itself, or is evolved manually by a trainer.
   */
  @Override
  public String execute(Actor actor, GameMap map) {
    String result = "";
    Location location = map.locationOf(target);
    AffectionManager affectionManager = AffectionManager.getInstance();
    // remove old Pokemon first
    map.removeActor(target);
    // add evolved Pokemon
    map.addActor(evolved, location);
    affectionManager.registerPokemon(evolved);
    if(!actor.hasCapability(Status.EVOLVING)) {
      affectionManager.increaseAffection(evolved, actor, EVOLVED_AP); //actor executing this action is a trainer
      result = actor + " evolved " + target + " into a " + evolved;
    }
    else {
      result = actor + " evolved into a " + evolved;
    }
    return result;
  }

  /**
   * The description displayed in the menu showing the action to be performed.
   *
   * @param actor The actor performing the action.
   * @return An indication of the action being performed.
   */
  @Override
  public String menuDescription(Actor actor) {
    return actor + " evolves " + target + " into " + evolved;
  }
}
