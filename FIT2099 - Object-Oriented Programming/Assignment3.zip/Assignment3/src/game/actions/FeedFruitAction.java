package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import game.tools.AffectionManager;
import game.enums.Element;
import game.tools.ElementsHelper;
import game.enums.Status;
import game.items.Pokefruit;
import game.pokemon.Pokemon;

/**
 * An Action to feed a Pokefruit to a Pokemon.
 * Created by:
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */
public class FeedFruitAction extends Action {

  /**
   * The Pokemon that is being fed.
   */
  private Pokemon fedPokemon;
  /**
   * The Affection Point increased if the Pokemon is fed a similar element Pokefruit.
   */
  private static final int INCREASE_AP = 20;
  /**
   * The Affection Point decreased if the Pokemon is fed a different element Pokefruit.
   */
  private static final int DECREASE_AP = 10;
  /**
   * The direction of the fed Pokemon.
   */
  private String direction;
  /**
   * The Pokefruit that is fed to the Pokemon.
   */
  private Pokefruit pokefruit;

  /**
   * Constructor.
   *
   * @param fedPokemon the Pokemon that is being fed.
   * @param pokefruit the Pokefruit that ie being fed to the Pokemon.
   * @param direction the direction of the fed Pokemon.
   */
  public FeedFruitAction(Pokemon fedPokemon, Pokefruit pokefruit, String direction){
    this.fedPokemon = fedPokemon;
    this.pokefruit = pokefruit;
    this.direction = direction;
  }

  /**
   * Execution of the Feed Fruit Action.
   *
   * @param actor The actor performing the action.
   * @param map The map the actor is on.
   * @return The result of the action (the Pokemon likes/dislikes the fruit).
   */
  @Override
  public String execute(Actor actor, GameMap map) {
    String result = "";
    AffectionManager affectionManager = AffectionManager.getInstance();
    //if it has a similar element to the given fruit,
    // it increases its affection level by 20 points
    if (ElementsHelper.hasAnySimilarElements(fedPokemon, pokefruit.findCapabilitiesByType(Element.class))){
      result += affectionManager.increaseAffection(fedPokemon,actor,INCREASE_AP) + " ";
      result += fedPokemon +" likes it! +20 affection points.";
    }

    // If the Pokemon doesn't have the same element as the given fruit,
    // it will decrease the affection by 10 points.
    else{
      affectionManager.decreaseAffection(fedPokemon,actor,DECREASE_AP);
      int post_feed_AP = affectionManager.getAffectionPoint(fedPokemon,actor);
      if (post_feed_AP<-50){
        fedPokemon.removeCapability(Status.CATCHABLE);
        fedPokemon.removeCapability(Status.FEEDABLE);
      }
      result += fedPokemon + " dislikes it! -10 affection points.";
    }

    actor.removeItemFromInventory(pokefruit);
    return result;
  }

  /**
   * The description displayed in the menu showing the action performed.
   *
   * @param actor The actor performing the action.
   * @return An indication of the Feed Fruit Action being performed.
   */
  @Override
  public String menuDescription(Actor actor) {
    //Ash gives Fire Fruit to Bulbasaur to the West
    return actor + " gives " + pokefruit + " to " + fedPokemon + " to the " + direction;
  }
}
