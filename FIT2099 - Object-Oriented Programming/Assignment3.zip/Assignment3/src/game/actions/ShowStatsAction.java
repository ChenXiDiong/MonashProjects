package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.positions.NumberRange;
import game.tools.AffectionManager;

/**
 * An action to print the status of Goh to the Player.
 * Created by:
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */
public class ShowStatsAction extends Action {

  /**
   * The target actor that has its status printed to the console.
   */
  private Actor targetActor;

  /**
   * Constructor.
   *
   * @param targetActor the target actor that has it status printed to the console.
   */
  public ShowStatsAction(Actor targetActor){
    this.targetActor = targetActor;
  }

  /**
   * Execution of the Show Stats Action.
   *
   * @param actor The actor performing the action.
   * @param map The map the actor is on.
   * @return The status of the target actor.
   */
  @Override
  public String execute(Actor actor, GameMap map) {
    System.out.println(targetActor + " | " + map.locationOf(targetActor).x() + "," + map.locationOf(targetActor).y() + " | inventory: " + targetActor.getInventory());
    AffectionManager affectionManager = AffectionManager.getInstance();
    System.out.println(affectionManager.listPokemons(targetActor, map));
    return "Stats of " + targetActor + " displayed.";
  }

  /**
   * The description displayed in the menu showing the action to be performed.
   *
   * @param actor The actor performing the action.
   * @return An indication of the action being performed.
   */
  @Override
  public String menuDescription(Actor actor) {
    return "Show stats of " + targetActor;
  }
}
