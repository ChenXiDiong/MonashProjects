package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;

import game.trading.Tradable;
import game.items.Candy;
import java.util.ArrayList;
import java.util.List;

/**
 * An Action to trade items with NurseJoy.
 * Created by:
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */
public class TradeAction extends Action {

  /**
   * The Item to be traded.
   */
  private Tradable tradeItem;
  /**
   * The number of candies required to trade the item.
   */
  private int candies;

  /**
   * Constructor.
   *
   * @param tradable the Item to be traded.
   * @param candies the number of candies required to trade the item.
   */
  public TradeAction(Tradable tradable, int candies){
    this.tradeItem = tradable;
    this.candies = candies;
  }

  /**
   * Execution of the Trade Action.
   *
   * @param actor The actor performing the action.
   * @param map The map the actor is on.
   * @return The result of the action (the item is successfully traded or not if Player has insufficient candies).
   */
  @Override
  public String execute(Actor actor, GameMap map) {
    String result = "";
    if (candiesInInventory(actor) < candies){
      result += "Fail! Insufficient Candies!";
      return result;
    }
    else{
      removeCandies(actor,candies);
      return tradeItem.trade(actor);
    }
  }

  /**
   * The description displayed in the menu showing the action performed.
   *
   * @param actor The actor performing the action.
   * @return An indication of the Trade Action being performed.
   */
  @Override
  public String menuDescription(Actor actor) {
    return actor + " trades " + tradeItem + " with " + candies+" candies.";
  }

  /**
   * Helper method to count the number of candies in the Player's inventory.
   *
   * @param actor The Player
   * @return An integer indicating the number of candies in the Player's inventory.
   */
  public int candiesInInventory(Actor actor){
    int counter = 0;
    for (Item item: actor.getInventory()){
      if (item instanceof Candy){
        counter++;
      }
    }
    return counter;
  }

  /**
   * Helper method to remove candies from the Player's inventory upon successful trade.
   *
   * @param actor The Player
   * @param removeCandies The number of candies to be removed from the Player's inventory.
   */
  public void removeCandies(Actor actor, int removeCandies){
    List<Item> inventory = new ArrayList<Item>();
    inventory.addAll(actor.getInventory());
    for (Item item: inventory){
      if (item instanceof Candy){
        removeCandies--;
        actor.removeItemFromInventory(item);
      }
      if (removeCandies==0){
        break;
      }
    }
  }
}
