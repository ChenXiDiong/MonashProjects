package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;

/**
 * An action of teleporting a Player from a map to another.
 * Created by:
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */
public class TeleportAction extends Action {

  /**
   * The location that the Actor would be teleported to.
   */
  private Location destination;
  /**
   * The name of the destination.
   */
  private String destinationName;


  /**
   * Constructor.
   *
   * @param destination the location that the Actor would be teleported to.
   * @param destinationName the name of the destination.
   */
  public TeleportAction(Location destination, String destinationName){
    this.destination = destination;
    this.destinationName = destinationName;
  }

  /**
   * Execution of the Teleport Action.
   *
   * @param actor The actor performing the action.
   * @param map The map the actor is on.
   * @return The result of the action (the actor is teleported to some destination).
   */
  @Override
  public String execute(Actor actor, GameMap map) {
    map.removeActor(actor);
    destination.addActor(actor);
    return actor + " is now at " + destinationName;
  }

  /**
   * The description displayed in the menu showing the action to be performed.
   *
   * @param actor The actor performing the action.
   * @return An indication of the action being performed.
   */
  @Override
  public String menuDescription(Actor actor) {
    return actor + " enters " + destinationName;
  }
}
