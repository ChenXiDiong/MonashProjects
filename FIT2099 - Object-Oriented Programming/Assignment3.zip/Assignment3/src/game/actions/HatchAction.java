package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.items.PokemonEgg;
import game.pokemon.Pokemon;

/**
 * An action to place down a Pokemon Egg on an Incubator.
 *
 * Created by:
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */
public class HatchAction extends Action {

  /**
   * the location to hatch the PokemonEgg.
   */
  private Location hatchLocation;
  /**
   * the PokemonEgg to be hatched.
   */
  private PokemonEgg pokemonEgg;

  /**
   * Constructor
   *
   * @param hatchLocation the location to hatch the PokemonEgg.
   * @param pokemonEgg the PokemonEgg to be hatched.
   */
  public HatchAction(Location hatchLocation, PokemonEgg pokemonEgg){
    this.hatchLocation = hatchLocation;
    this.pokemonEgg = pokemonEgg;
  }

  /**
   * Execution of the Hatch Action.
   *
   * @param actor The actor performing the action.
   * @param map The map the actor is on.
   * @return The result of the action (the player hatches a PokemonEgg at the Incubator.
   */
  @Override
  public String execute(Actor actor, GameMap map) {
    hatchLocation.addItem(pokemonEgg);
    return pokemonEgg + " hatching in Incubator at " + hatchLocation;
  }

  /**
   * The description displayed in the menu showing the action to be performed.
   *
   * @param actor The actor performing the action.
   * @return An indication of the action being performed.
   */
  @Override
  public String menuDescription(Actor actor) {
    return actor + " hatches " + pokemonEgg + " in the Incubator at " + hatchLocation;
  }
}
