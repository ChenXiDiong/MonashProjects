package game.items;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import game.enums.Status;
import game.pokemon.Pokemon;
import game.trading.Tradable;

/**
 * The PokemonEgg Item.
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */
public class PokemonEgg extends Item implements Tradable {

  /**
   * The display name of the PokemonEgg.
   */
  private static final String POKEMONEGG_NAME = "Pokemon Egg";
  /**
   * The display character of the PokemonEgg.
   */
  private static final char POKEMONEGG_DISPLAY_CHAR = 'g';
  /**
   * An indication of whether the PokemonEgg is portable.
   */
  private static final boolean POKEMONEGG_IS_PORTABLE = true;
  /**
   * The Pokemon that is contained within the Pokemon Egg.
   */
  private Pokemon hatchedPokemon;
  /**
   * The number of turns it takes to hatch the Pokemon Egg.
   */
  private int hatchTime;

  /**
   * Constructor.
   *
   * @param hatchedPokemon the Pokemon that can be hatched from the Pokemon Egg.
   * @param hatchTime the number of turns it takes to hatch the Pokemon Egg.
   */
  public PokemonEgg(Pokemon hatchedPokemon, int hatchTime) {
    super(POKEMONEGG_NAME, POKEMONEGG_DISPLAY_CHAR, POKEMONEGG_IS_PORTABLE);
    this.hatchedPokemon = hatchedPokemon;
    this.hatchTime = hatchTime;
    this.addCapability(Status.HATCHABLE);
  }

  /**
   * A method that is called when the Pokemon Egg is hatching in an Incubator.
   *
   * @return a Pokemon if the egg is hatched.
   */
  public Pokemon hatch(){
    this.hatchTime -= 1;
    if(this.hatchTime <= 0){
      return hatchedPokemon;
    }
    return null;
  }

  /**
   * A description of the PokemonEgg being traded for.
   *
   * @param by the actor doing the trade.
   * @return The result of the item being traded.
   */
  @Override
  public String trade(Actor by) {
    return by + " traded for a " + POKEMONEGG_NAME + " with a " + hatchedPokemon;
  }
}
