package game.items;

import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.Location;
import game.enums.Element;
import game.enums.Status;

/**
 * A Fire item that is dropped by FireSpin.
 * Created by:
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */
public class Fire extends Item {

    /**
     * The display character of the Fire Item.
     */
    private static final char FIRE_DISPLAY_CHAR = 'v';
    /**
     * The display name of the Fire Item.
     */
    private static final String FIRE_NAME = "Fire";
    /**
     * An indication of whether the Fire Item is portable.
     */
    private static final boolean FIRE_IS_PORTABLE = false;
    /**
     * The damage applied to other Actors that are not of the same element.
     */
    private static final int FIRE_DAMAGE=10;
    /**
     * The number of turns the Item is existent on the map.
     */
    private static int turn=0;

    /**
     * Constructor.
     */
    public Fire(){
      super(FIRE_NAME,FIRE_DISPLAY_CHAR, FIRE_IS_PORTABLE);
      this.addCapability(Element.FIRE);
      this.turn =0;
    }

    /**
     * Parses a turn to check whether the current Fire Item should be removed.
     *
     * @param currentLocation The location of the Fire Item.
     */
    @Override
    public void tick(Location currentLocation) {
        this.turn++;
        for (Exit exit: currentLocation.getExits()){
            Location surrounding= exit.getDestination();
            if (surrounding.containsAnActor() && !surrounding.getActor().hasCapability(Element.FIRE) &&
             !surrounding.getActor().hasCapability(Status.IMMUNE)){
                surrounding.getActor().hurt(FIRE_DAMAGE);
            }

        }
        if (this.turn ==2){
            currentLocation.removeItem(this);
        }

    }
}
