package game.trading;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.GameMap;
import game.items.PokemonEgg;
import game.players.Goh;
import game.players.Player;
import game.pokemon.Bulbasaur;
import game.pokemon.Squirtle;
import game.tools.AffectionManager;
import game.enums.Element;
import game.actions.TradeAction;
import game.items.Pokeball;
import game.items.Pokefruit;
import game.pokemon.Charmander;

/**
 * Nurse Joy class.
 *
 * She is a trader that the player can interact with to trade for useful items,
 * she is located in the middle of the game map inside a house.
 *
 * Created by:
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */

public class NurseJoy extends Actor {

  /**
   * The name of Nurse Joy.
   */
  private static final String NURSEJOY_NAME = "Nurse Joy";
  /**
   * The display character of Nurse Joy.
   */
  private static final char NURSEJOY_DISPLAY_CHAR = '%';
  /**
   * The number of hitpoints Nurse Joy has.
   */
  private static final int NURSEJOY_HP = 100;
  /**
   * The amount of candies required to trade for a PokeFruit.
   */
  private static final int CANDY_FOR_POKEFRUIT = 1;
  /**
   * The amount of candies required to trade for a PokemonEgg with a Charmander.
   */
  private static final int CANDY_FOR_CHARMANDER = 5;
  /**
   * The amount of candies required to trade for a PokemonEgg with a Bulbasaur.
   */
  private static final int CANDY_FOR_BULBASAUR = 5;
  /**
   * The amount of candies required to trade for a PokemonEgg with a Squirtle.
   */
  private static final int CANDY_FOR_SQUIRTLE = 5;
  /**
   * The number of AP that a traded Pokemon has.
   */
  private static final int POKEMON_AP = 50;
  /**
   * The number of turns to hatch a Charmander PokemonEgg.
   */
  private static final int CHARMANDER_HATCH_TIME = 4;
  /**
   * The number of turns to hatch a Bulbasaur PokemonEgg.
   */
  private static final int BULBASAUR_HATCH_TIME = 3;
  /**
   * The number of turns to hatch a Squirtle PokemonEgg.
   */
  private static final int SQUIRTLE_HATCH_TIME = 2;

  /**
   * Singleton instance (the one and only for a whole game).
   */
  private static NurseJoy instance = null;

  /**
   * The Constructor.
   *
   */
  private NurseJoy() {
    super(NURSEJOY_NAME, NURSEJOY_DISPLAY_CHAR, NURSEJOY_HP);
  }

  /**
   * get instance method to get an instance of nurse Joy
   *
   * @return instance ( of Nurse Joy )
   */
  public static NurseJoy getInstance() {
    if(instance == null) {
      instance = new NurseJoy();
    }
    return instance;
  }

  /**
   * playTurn method for nurse Joy that returns DoNothingAction since nurse Joy does not do anything other than trade ( player interaction )
   *
   * @param actions    collection of possible Actions for this Actor
   * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction()
   * @param map        the map containing the Actor
   * @param display    the I/O object to which messages may be written
   * @return DoNothingAction ( since nurse Joy does not have a play turn ( actions ) )
   *
   */
  @Override
  public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
    return new DoNothingAction();
  }

  /**
   * Provides a list of allowable actions for the Player from Nurse Joy.
   *
   * @param otherActor the Actor that might be performing attack
   * @param direction  String representing the direction of the other Actor
   * @param map        current GameMap
   * @return actions
   *
   */
  @Override
  public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
    // trade pokemon ( charmander )
    Charmander charmander = new Charmander();
    Bulbasaur bulbasaur = new Bulbasaur();
    Squirtle squirtle = new Squirtle();

    //Registering the Pokemons with the affectionManager
    AffectionManager affectionManager = AffectionManager.getInstance();
    Goh goh = Goh.getInstance();
    Player player = Player.getInstance();
    affectionManager.increaseAffection(charmander, player, POKEMON_AP);
    affectionManager.increaseAffection(bulbasaur, player, POKEMON_AP);
    affectionManager.increaseAffection(squirtle, player, POKEMON_AP);
    affectionManager.increaseAffection(charmander, goh, POKEMON_AP);
    affectionManager.increaseAffection(bulbasaur, goh, POKEMON_AP);
    affectionManager.increaseAffection(squirtle, goh, POKEMON_AP);

    //Creating the tradable items for TradeAction
    Tradable charmanderEgg = new PokemonEgg(charmander, CHARMANDER_HATCH_TIME);
    Tradable bulbasaurEgg = new PokemonEgg(bulbasaur, BULBASAUR_HATCH_TIME);
    Tradable squirtleEgg = new PokemonEgg(squirtle, SQUIRTLE_HATCH_TIME);
    Tradable fire = new Pokefruit(Element.FIRE);
    Tradable water = new Pokefruit(Element.WATER);
    Tradable grass = new Pokefruit(Element.GRASS);

    // trade action :
    ActionList actions = new ActionList();
    actions.add(new TradeAction(charmanderEgg,CANDY_FOR_CHARMANDER));
    actions.add(new TradeAction(bulbasaurEgg,CANDY_FOR_BULBASAUR));
    actions.add(new TradeAction(squirtleEgg,CANDY_FOR_SQUIRTLE));
    actions.add(new TradeAction(fire,CANDY_FOR_POKEFRUIT));
    actions.add(new TradeAction(water,CANDY_FOR_POKEFRUIT));
    actions.add(new TradeAction(grass,CANDY_FOR_POKEFRUIT));
    return actions;
  }

}
