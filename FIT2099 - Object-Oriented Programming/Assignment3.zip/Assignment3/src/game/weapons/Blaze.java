package game.weapons;

import edu.monash.fit2099.engine.weapons.WeaponItem;

/**
 * Blaze ( weapon ) class.
 * Created by:
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */
public class Blaze extends WeaponItem {

  /**
   * The name of this weapon is :
   */
  private final static String BLAZE_NAME = "blaze";

  /**
   * The display char of this weapon :
   */
  private final static char BLAZE_DISPLAY_CHAR = 'L';

  /**
   * The amount of damage that this weapon deals :
   */
  private final static int BLAZE_DAMAGE =60;

  /**
   * Action verb when attacking using this weapon :
   */
  private final static String BLAZE_VERB = "";

  /**
   * The hit rate of this weapon :
   */
  private final static int BLAZE_HIT_RATE = 90;

  /**
   * Constructor.
   */
  public Blaze(){
    super(BLAZE_NAME,BLAZE_DISPLAY_CHAR,BLAZE_DAMAGE,BLAZE_VERB,BLAZE_HIT_RATE);
  }
}
