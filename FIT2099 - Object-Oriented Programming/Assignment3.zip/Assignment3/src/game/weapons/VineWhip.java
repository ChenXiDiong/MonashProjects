package game.weapons;

import edu.monash.fit2099.engine.weapons.WeaponItem;

/**
 * Vine Whip class
 *
 * Vine Whip is a weapon in this game, this class is an extension of WeaponItem since Vine Whip is a weapon item
 * Vine Whip is a weapon with specific attributes ( attack power / hit rate, etc.. )
 *
 * Created by:
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */
public class VineWhip extends WeaponItem {

  // variables ( attributes, display char, etc.. for Vine Whip )
  /**
   * weapon name :
   */
  private final static String VINE_WHIP_NAME = "Vine Whip";

  /**
   * display char of Vine Whip :
   */
  private final static char VINE_WHIP_DISPLAY_CHAR = 'V';

  /**
   * damage dealt by each attack of this weapon :
   */
  private final static int VINE_WHIP_DAMAGE = 30;

  /**
   * Action verb when attacking using this weapon :
   */
  private final static String VINE_WHIP_VERB = "whips";

  /**
   * the hit rate of this weapon :
   */
  private final static int VINE_WHIP_HIT_RATE = 70;

  /**
   * Constructor
   */
  public VineWhip(){
    super(VINE_WHIP_NAME,VINE_WHIP_DISPLAY_CHAR,VINE_WHIP_DAMAGE,VINE_WHIP_VERB,VINE_WHIP_HIT_RATE);

  }
}
