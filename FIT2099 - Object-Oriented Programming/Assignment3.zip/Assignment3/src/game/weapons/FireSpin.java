package game.weapons;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.enums.Element;
import game.items.Fire;
import game.tools.AffectionManager;

/**
 * FireSpin ( weapon ) class.
 * Created by:
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */
public class FireSpin extends WeaponItem {
  /**
   * The name of this weapon is :
   */
  private final static String FIRESPIN_NAME = "fire spin";

  /**
   * The display char of this weapon :
   */
  private final static char FIRESPIN_DISPLAY_CHAR = 'F';

  /**
   * The amount of damage that this weapon deals :
   */
  private final static int FIRESPIN_DAMAGE = 70;

  /**
   * Action verb when attacking using this weapon :
   */
  private final static String FIRESPIN_VERB = "spins";

  /**
   * The hit rate of this weapon :
   */
  private final static int FIRESPIN_HIT_RATE = 90;

  /**
   * Constructor
   */
  public FireSpin(){
    super(FIRESPIN_NAME,FIRESPIN_DISPLAY_CHAR,FIRESPIN_DAMAGE,FIRESPIN_VERB,FIRESPIN_HIT_RATE);
  }

  /**
   * Executes the turned based method that burns the surrounding grounds of the actor carrying this Item.
   * @param currentLocation The location of the actor carrying this Item.
   * @param actor The actor carrying this Item.
   */
  @Override
  public void tick(Location currentLocation, Actor actor) {
    // At every turn (when it is equipped),
    // it burns the surrounding (8 squares) by dropping a Fire v
    for(Exit exit: currentLocation.getExits()){
      Location surrounding= exit.getDestination();
      if (!surrounding.containsAnActor()){
        surrounding.addItem(new Fire());
      }
    }

  }
}
