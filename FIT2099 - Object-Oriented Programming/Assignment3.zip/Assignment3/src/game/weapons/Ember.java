package game.weapons;

import edu.monash.fit2099.engine.weapons.WeaponItem;

/**
 * Ember ( weapon ) class
 * Ember is another weapon that is an extension of WeaponItem and has its own specific attributes ( char display, hit rate, etc. )
 *
 * Created by:
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */
public class Ember extends WeaponItem {

  // variables declaration ( name, display char, damage, etc )

  /**
   * The name of this weapon :
   */
  private static final String EMBER_NAME = "Ember";

  /**
   * The display char of this weapon :
   */
  private static final char EMBER_DISPLAY_CHAR = 'E';

  /**
   * The amount of damage that this weapon deals :
   */
  private static final int EMBER_DAMAGE = 20;

  /**
   * Action verb when attacking using this weapon :
   */
  private static final String EMBER_VERB = "sparks";

  /**
   * The hit rate of this weapon is :
   */
  private static final int EMBER_HIT_RATE = 90;

  /**
   * Constructor
   */
  public Ember(){
    super(EMBER_NAME, EMBER_DISPLAY_CHAR, EMBER_DAMAGE,EMBER_VERB,EMBER_HIT_RATE);
  }
}