package game.tools;

import edu.monash.fit2099.engine.actors.Actor;

import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.pokemon.Pokemon;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Affection Manager
 * <p>
 * Created by:
 * @author Riordan D. Alfredo
 * Modified by:
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */
public class AffectionManager {

    /**
     * Singleton instance (the one and only for a whole game).
     */
    private static AffectionManager instance;
    /**
     * HINT: is it just for a Charmander?
     */
    private final Map<Pokemon, Map<Actor, Integer>> affectionPoints;

    /**
     * We assume there's only one trainer in this manager.
     * Think about how will you extend it.
     */
    private ArrayList<Actor> trainers;
    /**
     * The maximum AP towards a Player that a Pokemon can reach.
     */
    private static final int MAX_AP_LEVEL=100;
    /**
     * The initial AP for Pokemons.
     */
    private static final int START_AP =0;

    /**
     * private singleton constructor
     */
    private AffectionManager() {
        this.affectionPoints = new HashMap<>();
        this.trainers = new ArrayList<>();
    }

    /**
     * Access single instance publicly
     *
     * @return this instance
     */
    public static AffectionManager getInstance() {
        if (instance == null) {
            instance = new AffectionManager();
        }
        return instance;
    }

    /**
     * Add a trainer to this class's attribute. Assume there's only one trainer at a time.
     *
     * @param trainer the actor instance
     */
    public void registerTrainer(Actor trainer) {
        this.trainers.add(trainer);
    }

    /**
     * Add Pokemon to the collection. By default, it has 0 affection point. Ideally, you'll register all instantiated Pokemon
     *
     * @param pokemon the pokemon to be registered.
     */
    public void registerPokemon(Pokemon pokemon) {
        affectionPoints.put(pokemon, new HashMap<>());
        for(Actor trainer : trainers) {
            affectionPoints.get(pokemon).put(trainer, START_AP);
        }
    }

    /**
     * Remove a Pokemon from the registered instances.
     * @param pokemon the Pokemon to be removed.
     */
    public void removePokemon(Pokemon pokemon) {
        affectionPoints.remove(pokemon);
    }



    /**
     * Get the affection point by using the pokemon instance as the key.
     *
     * @param pokemon Pokemon instance
     * @param actor The actor that the Pokemon has AP towards.
     * @return integer of affection point.
     */
    public int getAffectionPoint(Pokemon pokemon,Actor actor) {
        return affectionPoints.get(pokemon).get(actor);
    }

    /**
     * Useful method to search a pokemon by using Actor instance.
     *
     * @param actor general actor instance
     * @return the Pokemon instance.
     */
    private Pokemon findPokemon(Actor actor){
        for(Pokemon pokemon:affectionPoints.keySet()) {
            if (pokemon.equals(actor)) {
                return pokemon;
            }
        }
        return null;
    }

    /**
     * Increase the affection. Work on both cases when there's a Pokemon,
     * or when it doesn't exist in the collection.
     *
     * @param targetPokemon the Pokemon to decrease the AP of.
     * @param actor Actor instance, but we expect a Pokemon here.
     * @param point positive affection modifier
     * @return custom message to be printed by Display instance later.
     */

    public String increaseAffection(Actor targetPokemon, Actor actor,int point) {
        String message ="";
        // when there's a Pokemon :
        Pokemon pokemon = findPokemon(targetPokemon);
        if(pokemon != null){
            int old_ap = getAffectionPoint(pokemon,actor);
            if (old_ap+point < MAX_AP_LEVEL){
                affectionPoints.get(targetPokemon).remove(actor);
                affectionPoints.get(targetPokemon).put(actor,old_ap+point);
                message = pokemon + " increases " + point;
            }
            else{
                affectionPoints.get(targetPokemon).remove(actor);
                affectionPoints.get(targetPokemon).put(actor,MAX_AP_LEVEL);
                message = pokemon + " reaches max AP level.";
            }
        }
        // when it
        //
        //
        // doesn't exist in the collection
        else{
            message = "The Pokemon doesn't exist in the collection";
        }
        // return the message :
        return message;
    }

    /**
     * Decrease the affection level. Work on both cases when it is
     *
     * @param targetPokemon the Pokemon to decrease the AP of.
     * @param actor Actor instance, but we expect a Pokemon here.
     * @param point positive affection modifier (to be subtracted later)
     * @return custom message to be printed by Display instance later.
     */
    public String decreaseAffection(Actor targetPokemon, Actor actor, int point) {
        String message ="";
        // when there's a Pokemon
        Pokemon pokemon = findPokemon(targetPokemon);
        if(pokemon != null){
            int old_ap = getAffectionPoint(pokemon,actor);
            affectionPoints.get(targetPokemon).remove(actor);
            affectionPoints.get(targetPokemon).put(actor,old_ap-point);
            message = actor + " decreases " + point;
        }

        // when it doesn't exist in the collection
        else{
            message = "The Pokemon doesn't exist in the collection";
        }
        return message;
    }

    /**
     * A string that can be displayed to show the affection level of all the Pokemons currently on the map to a certain Actor.
     *
     * @param actor a trainer.
     * @param map the map that contains the Pokemons.
     * @return a string of all the Pokemons with their respective AP with the actor.
     */
    public String listPokemons(Actor actor, GameMap map){
        String ret_str = "";
        for(Pokemon pokemon : affectionPoints.keySet()){
            Location loc = map.locationOf(pokemon);
            if(loc != null){
                ret_str += "- " + pokemon.toString() + " at " + loc.x() + "," + loc.y() + " with " + affectionPoints.get(pokemon).get(actor) + " AP\n";
            }
        }
        return ret_str;
    }

}
