package game.tools;
import java.util.Random;

/**
 * Utils class for the Pokemon game
 *
 * Created by:
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */
public class Utils {
    private static Random random = new Random();

    /**
     * This will Generates a random double between 0 and 1 to indicate a random probability.
     *
     * @return A double between 0 and 1.
     */
    public static double generateRandomProbability(){
      return random.nextFloat();
    }

}
