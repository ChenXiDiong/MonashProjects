package game.pokemon;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.IntrinsicWeapon;
import game.actions.CatchAction;
import game.actions.EvolveAction;
import game.behaviours.EvolveBehaviour;
import game.time.TimePerception;
import game.tools.AffectionManager;
import game.actions.AttackAction;
import game.enums.Element;
import game.weapons.Ember;
import game.actions.FeedFruitAction;
import game.players.Player;
import game.items.Pokefruit;
import game.enums.Status;
import game.behaviours.AttackBehaviour;
import game.behaviours.Behaviour;
import game.behaviours.FollowBehaviour;
import game.behaviours.WanderBehaviour;

/**
 * The Charmander Pokemon.
 *
 * Created by:
 * @author Riordan D. Alfredo
 * Modified by:
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */
public class Charmander extends Pokemon implements TimePerception {

    /**
     * The name of Charmander.
     */
    private static final String POKEMON_C = "Charmander";
    /**
     * The display character of Charmander.
     */
    private static final char CHARMANDER_DISPLAY_CHAR = 'c';
    /**
     * The hitpoints that Charmander has.
     */
    private static final int CHARMANDER_HITPOINTS = 100;
    /**
     * The amount of heal received by Charmander from day effect.
     */
    private static final int CHARMANDER_HEAL = 10;
    /**
     * The amount of damage received by Charmander from night effect.
     */
    private static final int CHARMANDER_HURT = 10;




    /**
     * Constructor.
     */
    public Charmander() {
        super(POKEMON_C, CHARMANDER_DISPLAY_CHAR, CHARMANDER_HITPOINTS);
        // add this instance to the time perception manager
        this.registerInstance();

        // HINT: add more relevant behaviours here
        this.addCapability(Element.FIRE);
    }

    /**
     * @param otherActor the Actor that might perform an action.
     * @param direction  String representing the direction of the other Actor
     * @param map        current GameMap
     * @return list of actions
     */
    @Override
    public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
        ActionList actions = super.allowableActions(otherActor, direction, map);
        if (!otherActor.hasCapability(Status.IMMUNE) && !otherActor.hasCapability(Element.FIRE)){
            actions.add(new AttackAction(this, direction));
        }

        if(otherActor.hasCapability(Status.GIVEABLE) && this.hasCapability(Status.FEEDABLE)){
            AffectionManager affectionManager = AffectionManager.getInstance();
            if(affectionManager.getAffectionPoint(this, otherActor) == 100){
                actions.add(new EvolveAction(this, new Charmeleon()));
            }
        }

        return actions;
    }

    /**
     * playTurn method for the Charmander that handle multi turn actions, and print the console menu
     *
     * @param actions    collection of possible Actions for this Actor
     * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction()
     * @param map        the map containing the Actor
     * @param display    the I/O object to which messages may be written
     * @return menu ( displays list of possible actions that can be done )
     */
    @Override
    public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
        //for each turn the Pokemon is alive
        this.aliveTurns += 1;

        if(this.aliveTurns >= 20){
            this.addCapability(Status.EVOLVING);
            addBehaviour(7,new EvolveBehaviour(new Charmeleon()));
        }

        //if pokemon is dead by day/night effect
        if(!this.isConscious()){
            map.removeActor(this);
            AffectionManager affectionManager = AffectionManager.getInstance();
            affectionManager.removePokemon(this);
            return new DoNothingAction();
        }
        // check condition for a special attack
        Location location = map.locationOf(this);
        if (location.getGround().hasCapability(Element.FIRE)){
            this.backupWeapons.addWeapon(new Ember());
            this.isEquipping = true;
        }
        else{
            this.isEquipping = false;
        }
        return super.playTurn(actions, lastAction, map, display);
    }

    /**
     * Creates and returns an intrinsic weapon.
     *
     * By default, a Charmander 'scratches' for 10 damage.
     *
     * @return a freshly-instantiated IntrinsicWeapon.
     */
    @Override
    protected IntrinsicWeapon getIntrinsicWeapon() {
        return new IntrinsicWeapon(10,"scratch");
    }

    /**
     * The day effect of Charmander.
     */
    @Override
    public void dayEffect() {
        if(!this.hasCapability(Status.IMMUNE)) {
            heal(CHARMANDER_HEAL);
        }
    }

    /**
     * The night effect of Charmander.
     */
    @Override
    public void nightEffect() {
        if(!this.hasCapability(Status.IMMUNE)) {
            hurt(CHARMANDER_HURT);
        }
    }




}
