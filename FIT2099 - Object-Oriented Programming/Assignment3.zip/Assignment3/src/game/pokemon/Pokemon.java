package game.pokemon;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.actions.CatchAction;
import game.actions.FeedFruitAction;
import game.behaviours.AttackBehaviour;
import game.behaviours.FollowBehaviour;
import game.behaviours.WanderBehaviour;
import game.items.Pokefruit;
import game.players.Player;
import game.tools.AffectionManager;
import game.weapons.BackupWeapons;
import game.enums.Status;
import game.behaviours.Behaviour;
import game.time.TimePerception;

import java.util.HashMap;
import java.util.Map;

/**
 * Abstract Pokemon class.
 *
 * Created by:
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */
public abstract class Pokemon extends Actor{
  /**
   * The backupWeapon the Pokemon has.
   */
  protected BackupWeapons backupWeapons;
  /**
   * Indication of whether the Pokemon is equipping the backupWeapon.
   */
  protected boolean isEquipping;
  /**
   * List of behaviours of the Pokemon.
   */
  protected final Map<Integer, Behaviour> behaviours = new HashMap<>(); // priority, behaviour
  /**
   * The number of turns that the Pokemon is alive on the map.
   */
  protected int aliveTurns = 1;
  /**
   * Constructor.
   *
   * @param name        the name of the Actor
   * @param displayChar the character that will represent the Actor in the display
   * @param hitPoints   the Actor's starting hit points
   */
  public Pokemon(String name, char displayChar, int hitPoints) {
    super(name, displayChar, hitPoints);
    backupWeapons = new BackupWeapons();
    // register Pokemon
    AffectionManager.getInstance().registerPokemon(this);
    this.addCapability(Status.FEEDABLE);
    this.addCapability(Status.CATCHABLE);
    addBehaviour(8,new AttackBehaviour());
    addBehaviour(10,new WanderBehaviour());

  }

  /**
   * A printable String of the Pokemon.
   *
   * @return a description of the Pokemon.
   */
  @Override
  public String toString() {
    // Charmander(100/100)
    return super.toString()+super.printHp();
  }

  /**
   * Put a selected weapon to the inventory
   *
   * @param isEquipping whether the Pokemon is equipping a backupWeapon.
   */
  public void toggleWeapon(boolean isEquipping) {

    // isEquipping means that the Pokemon is standing on the required element ground.
    if (isEquipping){
      WeaponItem weaponItem = backupWeapons.getWeapon();
      this.addItemToInventory(weaponItem);
    }

    // Otherwise, it un-equips the weapon (i.e., remove it from the inventory)
    // avoid normal attack to use special weapon in the inventory

    else if (this.getInventory().size() > 0){ // if pokemon has a weapon equipped
      WeaponItem weaponItem = backupWeapons.getWeapon();
      this.removeItemFromInventory(weaponItem);
    }
  }

  /**
   * Adds a behaviour to the Pokemon.
   *
   * @param priority the priority level of the behaviour to be added.
   * @param behaviour the behaviour to be added.
   */
  public void addBehaviour(int priority,Behaviour behaviour){
    behaviours.put(priority,behaviour);
  }

  @Override
  public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display){
    // call toggleWeapon to equip the special weapon
    toggleWeapon(isEquipping);

    for (Behaviour behaviour : behaviours.values()) {
      Action action = behaviour.getAction(this, map);
      if (action != null)
        return action;
    }
    // if there's nothing, then it will do nothing...
    return new DoNothingAction();
  }

  @Override
  public ActionList allowableActions(Actor otherActor, String direction, GameMap map){
    ActionList actions = new ActionList();
    // allow the Player to capture
    if(otherActor.hasCapability(Status.GIVEABLE) && this.hasCapability(Status.FEEDABLE)){
      for(Item item: otherActor.getInventory()){
        if(item.hasCapability(Status.GIVEABLE)){
          actions.add(new FeedFruitAction(this, (Pokefruit) item, direction));
        }
      }


      //check condition for follow behaviour
      AffectionManager affectionManager = AffectionManager.getInstance();
      if(affectionManager.getAffectionPoint(this,otherActor) >= 75){
        addBehaviour(9 , new FollowBehaviour(otherActor));
      }
    }

    if(this.hasCapability(Status.CATCHABLE)){
      actions.add(new CatchAction(this,direction));
    }
    return actions;
  }
}

