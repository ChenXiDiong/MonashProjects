package game.pokemon;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.IntrinsicWeapon;
import game.actions.CatchAction;
import game.actions.EvolveAction;
import game.behaviours.EvolveBehaviour;
import game.tools.AffectionManager;
import game.actions.AttackAction;
import game.enums.Element;
import game.tools.Utils;
import game.weapons.Blaze;
import game.weapons.Ember;
import game.actions.FeedFruitAction;
import game.players.Player;
import game.items.Pokefruit;
import game.enums.Status;
import game.behaviours.AttackBehaviour;
import game.behaviours.Behaviour;
import game.behaviours.FollowBehaviour;
import game.behaviours.WanderBehaviour;

/**
 * The Charmeleon Pokemon.
 *
 * Created by:
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */
public class Charmeleon extends Pokemon{

  /**
   * The name of Charmeleon.
   */
  private static final String POKEMON_CH = "Charmeleon";
  /**
   * The display character of Charmeleon.
   */
  private static final char CHARMELEON_DISPLAY_CHAR = 'C';
  /**
   * The hitpoints that Charmeleon has.
   */
  private static final int CHARMELEON_HITPOINTS = 150;
  /**
   * The chance of Charmeleon equipping Blaze.
   */
  private static final double CHARMELEON_BLAZE_EQUIP_CHANCE = 1/2;

  /**
   * Constructor.
   */
  public Charmeleon() {
    super(POKEMON_CH, CHARMELEON_DISPLAY_CHAR, CHARMELEON_HITPOINTS);
    this.addCapability(Element.FIRE);
    this.addCapability(Status.EVOLVING);
  }

  /**
   * @param otherActor the Actor that might perform an action.
   * @param direction  String representing the direction of the other Actor
   * @param map        current GameMap
   * @return list of actions
   */
  @Override
  public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
    ActionList actions = super.allowableActions(otherActor, direction, map);

    if (!otherActor.hasCapability(Status.IMMUNE) && !otherActor.hasCapability(Element.FIRE)){
      actions.add(new AttackAction(this, direction));
    }

    if(otherActor.hasCapability(Status.GIVEABLE) && this.hasCapability(Status.FEEDABLE)){
      AffectionManager affectionManager = AffectionManager.getInstance();
      if(affectionManager.getAffectionPoint(this, otherActor) == 100){
        actions.add(new EvolveAction(this, new Charizard()));
      }
    }

    return actions;

  }

  /**
   * playTurn method for the Charmeleon that handle multi turn actions, and print the console menu
   *
   * @param actions    collection of possible Actions for this Actor
   * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction()
   * @param map        the map containing the Actor
   * @param display    the I/O object to which messages may be written
   * @return menu ( displays list of possible actions that can be done )
   */
  @Override
  public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
    //for each turn the Pokemon is alive
    this.aliveTurns += 1;

    if(this.aliveTurns >= 20){
      this.addCapability(Status.EVOLVING);
      addBehaviour(7,new EvolveBehaviour(new Charizard()));
    }

    // check condition for a special attack
    Location location = map.locationOf(this);
    if (location.getGround().hasCapability(Element.FIRE)){
      if(Utils.generateRandomProbability() < CHARMELEON_BLAZE_EQUIP_CHANCE) {
        this.backupWeapons.addWeapon(new Ember());
      }
      else {
        this.backupWeapons.addWeapon(new Blaze());
      }
      this.isEquipping = true;
    }
    else{
      this.isEquipping = false;
    }
    return super.playTurn(actions, lastAction, map, display);
  }

  /**
   * Creates and returns an intrinsic weapon.
   *
   * By default, a Charmeleon 'scratches' for 10 damage.
   *
   * @return a freshly-instantiated IntrinsicWeapon.
   */
  @Override
  protected IntrinsicWeapon getIntrinsicWeapon() {
    return new IntrinsicWeapon(10,"scratch");
  }



}

