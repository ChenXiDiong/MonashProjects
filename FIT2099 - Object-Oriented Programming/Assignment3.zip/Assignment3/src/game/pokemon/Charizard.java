package game.pokemon;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.IntrinsicWeapon;
import game.actions.CatchAction;
import game.tools.AffectionManager;
import game.actions.AttackAction;
import game.enums.Element;
import game.tools.Utils;
import game.weapons.Blaze;
import game.weapons.Ember;
import game.actions.FeedFruitAction;
import game.players.Player;
import game.items.Pokefruit;
import game.enums.Status;
import game.behaviours.Behaviour;
import game.behaviours.FollowBehaviour;
import game.weapons.FireSpin;

/**
 * The Charmeleon Pokemon.
 *
 * Created by:
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */
public class Charizard extends Pokemon{

  /**
   * The name of Charizard.
   */
  private static final String POKEMON_CZ = "Charizard";
  /**
   * The display character of Charizard.
   */
  private static final char CHARIZARD_DISPLAY_CHAR = 'Z';
  /**
   * The amount of hitpoints that Charizard has.
   */
  private static final int CHARIZARD_HITPOINTS = 250;
  /**
   * The probability of equipping Ember
   */
  private static final double CHARIZARD_EMBER_EQUIP_CHANCE = 1/3;
  /**
   * The probability of equipping Blaze.
   */
  private static final double CHARIZARD_BLAZE_EQUIP_CHANCE = 2/3;

  /**
   * Constructor.
   */
  public Charizard() {
    super(POKEMON_CZ, CHARIZARD_DISPLAY_CHAR, CHARIZARD_HITPOINTS);
    this.addCapability(Element.FIRE);
    this.addCapability(Element.DRAGON);
  }

  /**
   * @param otherActor the Actor that might perform an action.
   * @param direction  String representing the direction of the other Actor
   * @param map        current GameMap
   * @return list of actions
   */
  @Override
  public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
    ActionList actions = super.allowableActions(otherActor, direction, map);
    if (!otherActor.hasCapability(Status.IMMUNE) && !otherActor.hasCapability(Element.FIRE)){
      actions.add(new AttackAction(this, direction));
    }
    return actions;
  }

  /**
   * playTurn method for the Charmeleon that handle multi turn actions, and print the console menu
   *
   * @param actions    collection of possible Actions for this Actor
   * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction()
   * @param map        the map containing the Actor
   * @param display    the I/O object to which messages may be written
   * @return menu ( displays list of possible actions that can be done )
   */
  @Override
  public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
    // check condition for a special attack
    Location location = map.locationOf(this);
    if (location.getGround().hasCapability(Element.FIRE)){
      double equipChance = Utils.generateRandomProbability();
      if(equipChance < CHARIZARD_EMBER_EQUIP_CHANCE) {
        this.backupWeapons.addWeapon(new Ember());
      }
      else if(equipChance >= CHARIZARD_EMBER_EQUIP_CHANCE && equipChance < CHARIZARD_BLAZE_EQUIP_CHANCE) {
        this.backupWeapons.addWeapon(new Blaze());
      }
      else {
        this.backupWeapons.addWeapon(new FireSpin());
      }
      this.isEquipping = true;
    }
    else{
      this.isEquipping = false;
    }

    return super.playTurn(actions, lastAction, map, display);
  }

  /**
   * Creates and returns an intrinsic weapon.
   *
   * By default, a Charizard 'scratches' for 10 damage.
   *
   * @return a freshly-instantiated IntrinsicWeapon.
   */
  @Override
  protected IntrinsicWeapon getIntrinsicWeapon() {
    return new IntrinsicWeapon(10,"scratch");
  }


}

