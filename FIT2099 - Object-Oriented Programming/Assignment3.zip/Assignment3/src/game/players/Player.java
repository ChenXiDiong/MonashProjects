package game.players;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.displays.Menu;
import game.actions.ShowStatsAction;
import game.enums.Status;
import game.time.TimePerceptionManager;
import game.tools.AffectionManager;


/**
 * This is the Class representing the Player.
 *
 * Created by: starter code was provided by the teaching team inside the assignment file
 *
 * @author Riordan D. Alfredo
 * Modified by:
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */
public class Player extends Actor {

	/**
	 * The menu displayed to the user.
	 */
	private final Menu menu = new Menu();

	/**
	 * Singleton instance (the one and only for a whole game).
	 */
	private static Player player = null;
	/**
	 * The name of the Player.
	 */
	private static final String PLAYER_NAME = "Ash";
	/**
	 * The display character of the Player.
	 */
	private static final char PLAYER_DISPLAY_CHAR = '@';
	/**
	 * The Player's hitpoints.
	 */
	private static final int PLAYER_HITPOINTS = 100;


	/**
	 * Constructor.
	 *
	 * @param name        Name to call the player in the UI
	 * @param displayChar Character to represent the player in the UI
	 * @param hitPoints   Player's starting number of hitpoints
	 */
	private Player(String name, char displayChar, int hitPoints) {
		super(name, displayChar, hitPoints);
		this.addCapability(Status.IMMUNE);
		this.addCapability(Status.TELEPORTABLE);
		this.addCapability((Status.CANENTERBUILDING));
		AffectionManager affectionManager = AffectionManager.getInstance();
		affectionManager.registerTrainer(this);
	}

	/**
	 * get Instance method for player
	 * @return Player singleton instance.
	 */
	public static Player getInstance(){
		if(player == null){
			player = new Player(PLAYER_NAME, PLAYER_DISPLAY_CHAR, PLAYER_HITPOINTS);
		}
		return player;
	}

	/**
	 * playTurn method for the Player ( ash ) that tick the time perception manager, handle multi turn actions, and print the console menu
	 *
	 * @param actions    collection of possible Actions for this Actor
	 * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction()
	 * @param map        the map containing the Actor
	 * @param display    the I/O object to which messages may be written
	 * @return menu ( displays list of possible actions that can be done )
	 */
	@Override
	public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
		System.out.println(getInventory());
		// tick the time perception manager
		TimePerceptionManager timePerceptionManager = TimePerceptionManager.getInstance();
		timePerceptionManager.run();

		// Handle multi-turn Actions
		if (lastAction.getNextAction() != null){
			return lastAction.getNextAction();
		}

		Goh goh = Goh.getInstance();
		actions.add(new ShowStatsAction(goh));

		// return/print the console menu
		return menu.showMenu(this, actions, display);
	}

	/**
	 * getting the display char for the player :
	 * @return super.getDisplayChar
	 */
	@Override
	public char getDisplayChar() {
		return super.getDisplayChar();
	}
}
