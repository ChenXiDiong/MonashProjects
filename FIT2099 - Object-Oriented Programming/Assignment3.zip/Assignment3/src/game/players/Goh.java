package game.players;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.CatchAction;
import game.behaviours.Behaviour;
import game.behaviours.CatchPokemonBehaviour;
import game.behaviours.FeedFruitBehaviour;
import game.behaviours.PickupItemBehaviour;
import game.behaviours.WanderBehaviour;
import game.enums.Status;
import game.items.Pokefruit;
import game.pokemon.Pokemon;
import game.tools.AffectionManager;
import java.util.HashMap;
import java.util.Map;

/**
 * The NPC character Goh.
 * Created by:
 * @author Chen Xi Diong, Gde Putu Guido Parsanda, Zicheng Xia
 */
public class Goh extends Actor {

  /**
   * The one and only instance of Goh.
   */
  private static Goh goh = null;
  /**
   * The name of Goh.
   */
  private static final String GOH_NAME = "Goh";
  /**
   * The display character of Goh.
   */
  private static final char GOH_DISPLAY_CHAR = 'G';
  /**
   * Goh's hitpoints.
   */
  private static final int GOH_HITPOINTS = 100;
  /**
   * List of behaviours of Goh.
   */
  protected final Map<Integer, Behaviour> behaviours = new HashMap<>(); // priority, behaviour

  /**
   * Private Constructor.
   *
   * @param name        the name of the Actor
   * @param displayChar the character that will represent the Actor in the display
   * @param hitPoints   the Actor's starting hit points
   */
  private Goh(String name, char displayChar, int hitPoints) {
    super(name, displayChar, hitPoints);
    this.addCapability(Status.IMMUNE);
    addBehaviour(7,new CatchPokemonBehaviour());
    addBehaviour(8,new FeedFruitBehaviour());
    addBehaviour(9,new PickupItemBehaviour());
    addBehaviour(10,new WanderBehaviour());
    AffectionManager affectionManager = AffectionManager.getInstance();
    affectionManager.registerTrainer(this);
  }

  /**
   * get Instance method for Goh.
   * @return Goh singleton instance.
   */
  public static Goh getInstance(){
    if(goh == null){
      goh = new Goh(GOH_NAME, GOH_DISPLAY_CHAR, GOH_HITPOINTS);
    }
    return goh;
  }


  /**
   * playTurn method for Goh that executes an Action from the list of actions provided from the Behaviours.
   *
   * @param actions    collection of possible Actions for this Actor
   * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction()
   * @param map        the map containing the Actor
   * @param display    the I/O object to which messages may be written
   * @return an Action that is to be executed by Goh.
   */
  @Override
  public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
    for (Behaviour behaviour : behaviours.values()) {
      Action action = behaviour.getAction(this, map);
      if (action != null)
        return action;

    }
    // Otherwise, do nothing
    return new DoNothingAction();
  }

  /**
   * Helper function to add a Behaviour.
   * @param priority the priority of the Behaviour in the behaviours list.
   * @param behaviour the Behaviour to be added.
   */
  public void addBehaviour(int priority,Behaviour behaviour){
    behaviours.put(priority,behaviour);
  }

  /**
   * Printable String of Goh.
   * @return the name of Goh.
   */
  @Override
  public String toString(){
    return GOH_NAME;
  }
}
