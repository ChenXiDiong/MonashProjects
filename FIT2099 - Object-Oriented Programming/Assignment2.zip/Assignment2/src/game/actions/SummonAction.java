package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.GameMap;
import game.enums.Status;
import game.items.Pokeball;
import game.pokemon.Pokemon;

/**
 * An Action to summon a Pokemon from the Pokeball.
 * Created by:
 * @author Lab4Group5
 */
public class SummonAction extends Action {

  /**
   * The Pokemon to be summoned.
   */
  private Pokemon targetPokemon;
  /**
   * The Pokeball containing the target Pokemon.
   */
  private Pokeball pokeball;

  /**
   * Constructor.
   *
   * @param pokeball the Pokeball containing the target Pokemon.
   * @param targetPokemon the Pokemon to be summoned.
   */
  public SummonAction(Pokeball pokeball, Pokemon targetPokemon){
    this.pokeball = pokeball;
    this.targetPokemon = targetPokemon;
  }

  /**
   * Execution of the Summon Action.
   *
   * @param actor The actor performing the action.
   * @param map The map the actor is on.
   * @return The result of the action (the Pokemon is summoned/failed to be summoned).
   */
  @Override
  public String execute(Actor actor, GameMap map) {
    targetPokemon.removeCapability(Status.IMMUNE);
    for(Exit exit : map.locationOf(actor).getExits()){
      if(!exit.getDestination().containsAnActor()) {
        exit.getDestination().addActor(targetPokemon);
        actor.removeItemFromInventory(pokeball);
        return "I choose you "+targetPokemon;
      }
    }
    return actor + " fails to summon a Pokemon";
  }

  /**
   * The description displayed in the menu showing the action performed.
   *
   * @param actor The actor performing the action.
   * @return An indication of the Summon Action being performed.
   */
  @Override
  public String menuDescription(Actor actor) {
    return actor + " summons " + targetPokemon;
  }
}
