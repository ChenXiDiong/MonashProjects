package game.grounds;

import edu.monash.fit2099.engine.positions.Location;
import game.enums.Element;
import game.items.Pokefruit;
import game.pokemon.Charmander;

/**
 * The Crater ground.
 * Created by:
 * @author Lab4Group5
 */
public class Crater extends SpawningGround {

  /**
   * The display character of the Crater.
   */
  private static final char CRATER_DISPLAY_CHAR = 'O';
  /**
   * The chance of spawning a Charmander.
   */
  private static final double CHARMANDER_SPAWN_CHANCE = 0.1;
  /**
   * The chance of dropping a Fire Pokefruit.
   */
  private static final double FIRE_POKEFRUIT_DROP_CHANCE = 0.25;
  /**
   * The minimum number of adjacent fire element grounds for the Crater to be able to spawn a Charmander.
   */
  private static final int NUMBER_FIRE_ELEMENT = 0;

  /**
   * Constructor.
   */
  public Crater() {
    super(CRATER_DISPLAY_CHAR);
    this.addCapability(Element.FIRE);
  }

  /**
   * Ticks over the Crater every turn and executes the turn-based methods.
   *
   * @param location The location of the Ground
   */
  @Override
  public void tick(Location location) {
    spawnPokemon(location, new Charmander(), CHARMANDER_SPAWN_CHANCE, Element.FIRE, NUMBER_FIRE_ELEMENT);
    dropPokeFruit(location, new Pokefruit(Element.FIRE), FIRE_POKEFRUIT_DROP_CHANCE);
  }
}
