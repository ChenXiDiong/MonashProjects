package game.grounds;

import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;
import game.tools.AffectionManager;
import game.enums.Element;
import game.items.Pokefruit;
import game.pokemon.Pokemon;
import game.tools.Utils;

/**
 * Abstract class of a ground that is able to Spawn Pokemons and Drop Pokefruits.
 *
 * Created by:
 * @author Lab4Group5
 */
public abstract class SpawningGround extends Ground {

  /**
   * The AffectionManager instance.
   */
  public AffectionManager affectionManager = AffectionManager.getInstance();

  /**
   * Constructor.
   *
   * @param displayChar the display character of the ground.
   */
  public SpawningGround(char displayChar) {
    super(displayChar);
  }

  /**
   * Spawns a Pokemon at the target location if conditions are met.
   *
   * @param location the location to spawn a Pokemon.
   * @param pokemonSpawned the Pokemon to be spawned.
   * @param spawnChance the chance of spawning the Pokemon.
   * @param elementCheck the element to be checked for adjacent grounds.
   * @param elementCount the minimum requirement of adjacent grounds with similar elements to spawn a Pokemon.
   */
  public void spawnPokemon(Location location, Pokemon pokemonSpawned, double spawnChance, Element elementCheck, int elementCount){
    int count = 0;
    for (Exit exit : location.getExits()){
      Location destination = exit.getDestination();
      if (destination.getGround().hasCapability(elementCheck)){
        count ++;
      }
    }
    if (Utils.generateRandomProbability()<spawnChance
        && !location.containsAnActor()&& count >=elementCount){
      location.addActor(pokemonSpawned);
      affectionManager.registerPokemon(pokemonSpawned);
    }
  };

  /**
   * Drops a Pokefruit at the target location if conditions are met.
   *
   * @param location the location to drop a Pokefruit.
   * @param pokefruit the Pokefruit to be dropped.
   * @param dropChance the chance of dropping the Pokefruit.
   */
  public void dropPokeFruit(Location location, Pokefruit pokefruit, double dropChance) {
    if(Utils.generateRandomProbability() < dropChance
        && !location.containsAnActor()){
      location.addItem(pokefruit);
    }
  }

}
