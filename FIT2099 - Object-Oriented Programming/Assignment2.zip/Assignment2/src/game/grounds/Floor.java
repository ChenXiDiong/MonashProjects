package game.grounds;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Ground;
import game.players.Player;

/**
 * A class that represents the floor inside a building.
 *
 * Created by:
 * @author Riordan D. Alfredo
 * Modified by:
 * @author Lab4Group5
 */
public class Floor extends Ground {
	private static final char FLOOR_DISPLAY_CHAR = '_';
	/**
	 * Constructor.
	 */
	public Floor() {
		super(FLOOR_DISPLAY_CHAR);
	}

	/**
	 * Checks whether the actor is able to stand on the Floor.
	 *
	 * @param actor the Actor to check
	 * @return true if the actor is the Player, false otherwise.
	 */
	@Override
	public boolean canActorEnter(Actor actor) {
		if(actor instanceof Player){
			return true;
		}
		return false;
	}
}
