package game.grounds;

import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.Location;
import game.items.Candy;
import game.enums.Element;
import game.tools.ElementsHelper;
import game.items.Pokefruit;
import game.pokemon.Bulbasaur;
import game.time.TimePerception;
import game.tools.Utils;

/**
 * The Tree ground.
 * Created by:
 * @author Lab4Group5
 */
public class Tree extends SpawningGround implements TimePerception, SpreadingGround {

    /**
     * The display character of Tree.
     */
    private static final char TREE_DISPLAY_CHAR = 'T';
    /**
     * The chance of spawning a Bulbasaur.
     */
    private static final double BULBASAUR_SPAWN_CHANCE = 0.15;
    /**
     * The chance of dropping a Grass Pokefruit.
     */
    private static final double GRASS_POKEFRUIT_DROP_CHANCE = 0.15;
    /**
     * The chance of spawning a Tree or a Hay.
     */
    private static final double TREE_SPAWN_CHANCE = 0.5;
    /**
     * The chance of carrying out the day effect of the Tree.
     */
    private static final double TREE_DAY_EFFECT = 0.05;
    /**
     * The chance of carrying out the night effect of the Tree
     */
    private static final double TREE_NIGHT_EFFECT = 0.1;
    /**
     * The minimum number of adjacent grass element grounds for the Tree to be able to spawn a Bulbasaur.
     */
    private static final int NUMBER_GRASS_ELEMENT = 1;
    /**
     * The location of the Tree.
     */
    private Location location;

    /**
     * Constructor.
     */
    public Tree() {
        super(TREE_DISPLAY_CHAR);
        this.addCapability(Element.GRASS);

        // add this instance to the relevant manager
        this.registerInstance();
    }

    /**
     * The day effect of Tree.
     */
    @Override
    public void dayEffect() {
        //Trees T have a 5% chance of dropping a Candy.
        if(this.location != null && Utils.generateRandomProbability() < TREE_DAY_EFFECT){
            dropCandy(location);
        }
    }

    /**
     * The night effect of Tree.
     */
    @Override
    public void nightEffect() {
        // Trees T have 10% chance to expand
        // (convert its surroundings to either all Trees or all Hays randomly).
        if (this.location != null && Utils.generateRandomProbability()< TREE_NIGHT_EFFECT){
            spreadGround(location);
        }
    }

    /**
     * Executes turn-based methods of the Tree ground.
     *
     * @param location The location of the Tree ground.
     */
    @Override
    public void tick(Location location) {
        this.location = location;
        spawnPokemon(location, new Bulbasaur(), BULBASAUR_SPAWN_CHANCE, Element.GRASS, NUMBER_GRASS_ELEMENT);
        dropPokeFruit(location, new Pokefruit(Element.GRASS), GRASS_POKEFRUIT_DROP_CHANCE);
    }

    /**
     * Drops a Candy at the target location.
     *
     * @param location the location to drop the Candy.
     */
    public void dropCandy(Location location){
        location.addItem(new Candy());
    }

    /**
     * Changes the adjacent grounds to Tree or Hay randomly if the condition is met.
     *
     * @param location the location of the Tree ground.
     */
    public void spreadGround(Location location){
        if(Utils.generateRandomProbability() < TREE_SPAWN_CHANCE){
            for(Exit exit : location.getExits()) {
                //The expanding grounds won't convert the Floors, Walls, and grounds with similar elements
                if (!(exit.getDestination().getGround() instanceof Wall)
                    && !(exit.getDestination().getGround() instanceof Floor)
                    && !(ElementsHelper.hasAnySimilarElements(location.getGround(),
                    exit.getDestination().getGround().findCapabilitiesByType(Element.class)))) {
                    exit.getDestination().setGround(new Tree());
                }
            }
        }
        else{
            for(Exit exit : location.getExits()) {
                //The expanding grounds won't convert the Floors, Walls, and grounds with similar elements
                if (!(exit.getDestination().getGround() instanceof Wall)
                    && !(exit.getDestination().getGround() instanceof Floor)
                    && !(ElementsHelper.hasAnySimilarElements(location.getGround(),
                    exit.getDestination().getGround().findCapabilitiesByType(Element.class)))) {
                    exit.getDestination().setGround(new Hay());
                }
            }
        }

    }

}
