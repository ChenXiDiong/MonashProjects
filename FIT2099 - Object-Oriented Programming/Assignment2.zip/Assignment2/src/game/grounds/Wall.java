package game.grounds;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Ground;

/**
 * The Wall ground.
 *
 * Created by:
 * @author Riordan D. Alfredo
 * Modified by:
 *
 * @author Lab4Group5
 */
public class Wall extends Ground {

	/**
	 * The display character of Wall.
	 */
	private static final char WALL_DISPLAY_CHAR = '#';
	/**
	 * Constructor.
	 */
	public Wall() {
		super(WALL_DISPLAY_CHAR);
	}

	/**
	 * No Actor can enter a Wall.
	 *
	 * @param actor the Actor to check
	 * @return false
	 */
	@Override
	public boolean canActorEnter(Actor actor) {
			return false;
		}

	/**
	 * Blocks all thrown objects.
	 *
	 * @return true
	 */
	@Override
	public boolean blocksThrownObjects() {
		return true;
	}
}
