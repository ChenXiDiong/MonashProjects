package game.grounds;

import edu.monash.fit2099.engine.positions.Ground;

/**
 * A class that represents bare dirt.
 * Created by:
 * @author Riordan D. Alfredo
 * Modified by:
 * @author Lab4Group5
 */
public class Dirt extends Ground {

    /**
     * The display character of Dirt.
     */
    private static final char DIRT_DISPLAY_CHAR = '.';
    /**
     * Constructor.
     */
    public Dirt() {
        super(DIRT_DISPLAY_CHAR);
    }
}
