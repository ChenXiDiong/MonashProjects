package game.trading;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.GameMap;
import game.tools.AffectionManager;
import game.enums.Element;
import game.actions.TradeAction;
import game.items.Pokeball;
import game.items.Pokefruit;
import game.pokemon.Charmander;

/**
 * Nurse Joy class.
 *
 * She is a trader that the player can interact with to trade for useful items,
 * she is located in the middle of the game map inside a house.
 *
 * Created by:
 * @author Lab4Group5
 */

public class NurseJoy extends Actor {
  // variable declaration :
  private static final String NURSEJOY_NAME = "Nurse Joy";
  private static final char NURSEJOY_DISPLAY_CHAR = '%';
  private static final int NURSEJOY_HP = 100;
  private static final int CANDY_FOR_POKEFRUIT = 1;
  private static final int CANDY_FOR_CHARMANDER = 5;

  /**
   * Singleton instance (the one and only for a whole game).
   */
  private static NurseJoy instance = null;

  /**
   * The Constructor.
   *
   */
  private NurseJoy() {
    super(NURSEJOY_NAME, NURSEJOY_DISPLAY_CHAR, NURSEJOY_HP);
  }

  /**
   * get instance method to get an instance of nurse Joy
   *
   * @return instance ( of Nurse Joy )
   */
  public static NurseJoy getInstance() {
    if(instance == null) {
      instance = new NurseJoy();
    }
    return instance;
  }

  /**
   * playTurn method for nurse Joy that returns DoNothingAction since nurse Joy does not do anything other than trade ( player interaction )
   *
   * @param actions    collection of possible Actions for this Actor
   * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction()
   * @param map        the map containing the Actor
   * @param display    the I/O object to which messages may be written
   * @return DoNothingAction ( since nurse Joy does not have a play turn ( actions ) )
   *
   */
  @Override
  public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
    return new DoNothingAction();
  }

  /**
   * Provides a list of allowable actions for the Player from Nurse Joy.
   *
   * @param otherActor the Actor that might be performing attack
   * @param direction  String representing the direction of the other Actor
   * @param map        current GameMap
   * @return actions
   *
   */
  @Override
  public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
    // trade pokemon ( charmander ), give pokefruit
    Charmander charmander = new Charmander();
    AffectionManager affectionManager = AffectionManager.getInstance();
    affectionManager.increaseAffection(charmander, 50);
    Tradable pokeball = new Pokeball(charmander);
    Tradable fire = new Pokefruit(Element.FIRE);
    Tradable water = new Pokefruit(Element.WATER);
    Tradable grass = new Pokefruit(Element.GRASS);


    // trade action :
    ActionList actions = new ActionList();
    actions.add(new TradeAction(pokeball,CANDY_FOR_CHARMANDER));
    actions.add(new TradeAction(fire,CANDY_FOR_POKEFRUIT));
    actions.add(new TradeAction(water,CANDY_FOR_POKEFRUIT));
    actions.add(new TradeAction(grass,CANDY_FOR_POKEFRUIT));
    return actions;
  }

}
