package game.trading;

import edu.monash.fit2099.engine.actors.Actor;

/**
 * Tradable interface.
 *
 * Created by:
 * @author Lab4Group5
 */
public interface Tradable {

  /**
   * A description of the Item being traded for.
   *
   * @param by the actor doing the trade.
   * @return The result of the item being traded.
   */
  String trade(Actor by);
}
