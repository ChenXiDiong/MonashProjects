package game.pokemon;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.tools.AffectionManager;
import game.weapons.BackupWeapons;
import game.enums.Status;
import game.behaviours.Behaviour;
import game.time.TimePerception;

import java.util.HashMap;
import java.util.Map;

/**
 * Abstract Pokemon class.
 *
 * Created by:
 * @author Lab4Group5
 */
public abstract class Pokemon extends Actor implements TimePerception {

  /**
   * The backupWeapon the Pokemon has.
   */
  BackupWeapons backupWeapons;
  /**
   * Indication of whether the Pokemon is equipping the backupWeapon.
   */
  Boolean isEquipping;
  /**
   * List of behaviours of the Pokemon.
   */
  protected final Map<Integer, Behaviour> behaviours = new HashMap<>(); // priority, behaviour


  /**
   * Constructor.
   *
   * @param name        the name of the Actor
   * @param displayChar the character that will represent the Actor in the display
   * @param hitPoints   the Actor's starting hit points
   */
  public Pokemon(String name, char displayChar, int hitPoints) {
    super(name, displayChar, hitPoints);
    backupWeapons = new BackupWeapons();
    // add this instance to the time perception manager
    this.registerInstance();
    // register Pokemon
    AffectionManager.getInstance().registerPokemon(this);
    this.addCapability(Status.FEEDABLE);

  }

  /**
   * A printable String of the Pokemon.
   *
   * @return a description of the Pokemon.
   */
  @Override
  public String toString() {
    String ap = "(AP: "+AffectionManager.getInstance().getAffectionPoint(this)+")";
    // Charmander(30/30)(AP:0)
    return super.toString()+super.printHp()+ap;
  }

  /**
   * Put a selected weapon to the inventory
   *
   * @param isEquipping whether the Pokemon is equipping a backupWeapon.
   */
  public void toggleWeapon(boolean isEquipping) {
    WeaponItem weaponItem = backupWeapons.getWeapon();
    // isEquipping means that the Pokemon is standing on the required element ground.
    if (isEquipping){
      this.addItemToInventory(weaponItem);
    }

    // Otherwise, it un-equips the weapon (i.e., remove it from the inventory)
    // avoid normal attack to use special weapon in the inventory

    else if (this.getInventory().size() > 0){ // if pokemon has a weapon equipped
      this.removeItemFromInventory(weaponItem);
    }
  }

  /**
   * Adds a behaviour to the Pokemon.
   *
   * @param priority the priority level of the behaviour to be added.
   * @param behaviour the behaviour to be added.
   */
  public void addBehaviour(int priority,Behaviour behaviour){
    behaviours.put(priority,behaviour);
  }
}

