package game.pokemon;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.IntrinsicWeapon;
import game.tools.AffectionManager;
import game.actions.AttackAction;
import game.weapons.Bubble;
import game.actions.CatchAction;
import game.enums.Element;
import game.actions.FeedFruitAction;
import game.players.Player;
import game.items.Pokefruit;
import game.enums.Status;
import game.behaviours.AttackBehaviour;
import game.behaviours.Behaviour;
import game.behaviours.FollowBehaviour;
import game.behaviours.WanderBehaviour;

/**
 * The Squirtle Pokemon.
 *
 * Created by:
 * @author Lab4Group5
 */
public class Squirtle extends Pokemon {

  /**
   * The name of Squirtle.
   */
  private static final String POKEMON_S = "Squirtle";
  /**
   * The display character of Squirtle.
   */
  private static final char SQUIRTLE_DISPLAY_CHAR = 's';
  /**
   * The hitpoints Squirtle has.
   */
  private static final int SQUIRTLE_HITPOINTS = 100;
  /**
   * The amount of heal received by Squirtle from night effect.
   */
  private static final int SQUIRTLE_HEAL = 10;
  /**
   * The amount of damage received by Squirtle from day effect.
   */
  private static final int SQUIRTLE_HURT = 10;


  /**
   * Constructor ( squirtle ).
   */
  public Squirtle() {
    super(POKEMON_S, SQUIRTLE_DISPLAY_CHAR, SQUIRTLE_HITPOINTS);
    this.backupWeapons.addWeapon(new Bubble());
    this.addCapability(Element.WATER);
    this.addCapability(Status.CATCHABLE);
    addBehaviour(8,new AttackBehaviour());
    addBehaviour(10,new WanderBehaviour());
  }

  /**
   * allowable actions of the Pokemon ( Squirtle )
   *
   * @param otherActor the Actor that might be performing attack
   * @param direction  String representing the direction of the other Actor
   * @param map        current GameMap
   * @return actions ( the thing that the Pokemon will  do )
   */
  @Override
  public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
    ActionList actions = new ActionList();
    // allow other actor to attack
    if (otherActor instanceof Pokemon && !otherActor.hasCapability(Element.WATER)){
      actions.add(new AttackAction(this, direction));
    }
    // allow the Player to capture
    else if (otherActor instanceof Player){
      if(this.hasCapability(Status.CATCHABLE)){
        actions.add(new CatchAction(this,direction));
      }
      if(otherActor.hasCapability(Status.GIVEABLE) && this.hasCapability(Status.FEEDABLE)){
        for(Item item: otherActor.getInventory()){
          if(item instanceof Pokefruit){
            actions.add(new FeedFruitAction(this, (Pokefruit) item, direction));
          }
        }
      }


      //check condition for follow behaviour
      AffectionManager affectionManager = AffectionManager.getInstance();
      if(affectionManager.getAffectionPoint(this) >= 75){
        addBehaviour(9 , new FollowBehaviour(otherActor));
      }
    }
    return actions;
  }

  /**
   * playTurn method for the Squirtle that handle multi turn actions, and print the console menu
   *
   * @param actions    collection of possible Actions for this Actor
   * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction()
   * @param map        the map containing the Actor
   * @param display    the I/O object to which messages may be written
   * @return menu ( displays list of possible actions that can be done )
   */
  @Override
  public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
    //if pokemon is dead by day/night effect
    if(!this.isConscious()){
      map.removeActor(this);
    }
    // check condition for a special attack
    Location location = map.locationOf(this);
    if (location.getGround().hasCapability(Element.WATER)){
      backupWeapons.addWeapon(new Bubble());
      isEquipping = true;
    }
    else{
      isEquipping = false;
    }
    // call toggleWeapon to equip the special weapon
    toggleWeapon(isEquipping);
    for (Behaviour behaviour : behaviours.values()) {
      Action action = behaviour.getAction(this, map);
      if (action != null)
        return action;
    }
    // otherwise, do nothing :
    return new DoNothingAction();
  }


  /**
   * Creates and returns an intrinsic weapon.
   *
   * By default, a Squirtle 'tackles' for 10 damage ( deals 10 damage ).
   *
   * @return a freshly-instantiated IntrinsicWeapon
   */
  @Override
  protected IntrinsicWeapon getIntrinsicWeapon() {
    return new IntrinsicWeapon(10,"tackle");
  }

  /**
   * The day effect of Squirtle.
   */
  @Override
  public void dayEffect() {
    if(!this.hasCapability(Status.IMMUNE)) {
      hurt(SQUIRTLE_HURT);
    }
  }

  /**
   * The night effect of Squirtle.
   */
  @Override
  public void nightEffect() {
    if(!this.hasCapability(Status.IMMUNE)) {
      heal(SQUIRTLE_HEAL);
    }
  }


}
