package game.pokemon;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.IntrinsicWeapon;
import game.tools.AffectionManager;
import game.actions.AttackAction;
import game.actions.CatchAction;
import game.enums.Element;
import game.actions.FeedFruitAction;
import game.players.Player;
import game.items.Pokefruit;
import game.enums.Status;
import game.weapons.VineWhip;
import game.behaviours.AttackBehaviour;
import game.behaviours.Behaviour;
import game.behaviours.FollowBehaviour;
import game.behaviours.WanderBehaviour;

/**
 * The Bulbasaur Pokemon.
 *
 * Created by:
 * @author Lab4Group5
 */
public class Bulbasaur extends Pokemon {

  /**
   * The name of Bulbasaur.
   */
  private static final String BULBASAUR_NAME = "Bulbasaur";
  /**
   * The display character of Bulbasaur.
   */
  private static final char BULBASAUR_DISPLAY_CHAR = 'b';
  /**
   * The hitpoints that Bulbasaur has.
   */
  private static final int BULBASAUR_HP = 100;
  /**
   * The amount of heal Bulbasaur receives from night effect.
   */
  private static final int BULBASAUR_HEAL = 5;
  /**
   * The amount of damage Bulbasaur receives from day effect.
   */
  private static final int BULBASAUR_HURT = 5;


  /**
   * Constructor.
   */
  public Bulbasaur() {
    super(BULBASAUR_NAME, BULBASAUR_DISPLAY_CHAR, BULBASAUR_HP);
    this.addCapability(Element.GRASS);
    this.addCapability(Status.CATCHABLE);
    this.backupWeapons.addWeapon(new VineWhip());
    addBehaviour(8,new AttackBehaviour());
    addBehaviour(10,new WanderBehaviour());

  }

  /**
   * allowable actions method for the Pokemon
   * @param otherActor the Actor that might be performing attack
   * @param direction  String representing the direction of the other Actor
   * @param map        current GameMap
   * @return actions
   */
  @Override
  public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
    ActionList actions = new ActionList();
    // this allows an actor ( other actor ) to attack a specific Bulbasaur :
    if (otherActor instanceof Pokemon && !otherActor.hasCapability(Element.GRASS)){
      actions.add(new AttackAction(this, direction));
    }
    // allow the Player to capture
    else if (otherActor instanceof Player){
      if(this.hasCapability(Status.CATCHABLE)){
        actions.add(new CatchAction(this,direction));
      }
      if(otherActor.hasCapability(Status.GIVEABLE) && this.hasCapability(Status.FEEDABLE)){
        for(Item item: otherActor.getInventory()){
          if(item instanceof Pokefruit){
            actions.add(new FeedFruitAction(this, (Pokefruit) item, direction));
          }
        }
      }

      //check condition for follow behaviour
      AffectionManager affectionManager = AffectionManager.getInstance();
      if(affectionManager.getAffectionPoint(this) >= 75){
        addBehaviour(9 , new FollowBehaviour(otherActor));
      }
    }
    return actions;

  }

  /**
   * playTurn method for the Bulbasaur that handle multi turn actions, and print the console menu
   *
   * @param actions    collection of possible Actions for this Actor
   * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction()
   * @param map        the map containing the Actor
   * @param display    the I/O object to which messages may be written
   * @return menu ( displays list of possible actions that can be done )
   */
  @Override
  public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
    //if pokemon is dead by day/night effect
    if(!this.isConscious()){
      map.removeActor(this);
    }
    // check condition for a special attack
    Location location = map.locationOf(this);
    if (location.getGround().hasCapability(Element.GRASS)){
      backupWeapons.addWeapon(new VineWhip());
      isEquipping = true;
    }
    else{
      isEquipping = false;
    }
    // call toggleWeapon to equip the special weapon
    toggleWeapon(isEquipping);

    for (Behaviour behaviour : behaviours.values()) {
      Action action = behaviour.getAction(this, map);
      if (action != null)
        return action;
    }
    // if there's nothing, then it will do nothing...
    return new DoNothingAction();
  }


  /**
   * Creates and returns an intrinsic weapon.
   *
   * By default, a Bulbasaur 'tackles' for 10 damage.
   *
   * @return a freshly-instantiated IntrinsicWeapon
   */
  @Override
  protected IntrinsicWeapon getIntrinsicWeapon() {
    return new IntrinsicWeapon(10,"tackle");
  }

  /**
   * The day effect of Bulbasaur.
   */
  @Override
  public void dayEffect() {
    if(!this.hasCapability(Status.IMMUNE)) {
      hurt(BULBASAUR_HURT);
    }
  }

  /**
   * The night effect of Bulbasaur.
   */
  @Override
  public void nightEffect() {
    if(!this.hasCapability(Status.IMMUNE)) {
      heal(BULBASAUR_HEAL);
    }
  }



}
