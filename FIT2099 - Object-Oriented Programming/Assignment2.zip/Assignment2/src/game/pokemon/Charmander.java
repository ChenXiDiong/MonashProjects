package game.pokemon;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.IntrinsicWeapon;
import game.tools.AffectionManager;
import game.actions.AttackAction;
import game.enums.Element;
import game.weapons.Ember;
import game.actions.FeedFruitAction;
import game.players.Player;
import game.items.Pokefruit;
import game.enums.Status;
import game.behaviours.AttackBehaviour;
import game.behaviours.Behaviour;
import game.behaviours.FollowBehaviour;
import game.behaviours.WanderBehaviour;

/**
 * The Charmander Pokemon.
 *
 * Created by:
 * @author Riordan D. Alfredo
 * Modified by:
 * @author Lab4Group5
 */
public class Charmander extends Pokemon{

    /**
     * The name of Charmander.
     */
    private static final String POKEMON_C = "Charmander";
    /**
     * The display character of Charmander.
     */
    private static final char CHARMANDER_DISPLAY_CHAR = 'c';
    /**
     * The hitpoints that Charmander has.
     */
    private static final int CHARMANDER_HITPOINTS = 100;
    /**
     * The amount of heal received by Charmander from day effect.
     */
    private static final int CHARMANDER_HEAL = 10;
    /**
     * The amount of damage received by Charmander from night effect.
     */
    private static final int CHARMANDER_HURT = 10;

    /**
     * Constructor.
     */
    public Charmander() {
        super(POKEMON_C, CHARMANDER_DISPLAY_CHAR, CHARMANDER_HITPOINTS);
        this.backupWeapons.addWeapon(new Ember());

        // HINT: add more relevant behaviours here
        this.addCapability(Element.FIRE);
        addBehaviour(8,new AttackBehaviour());
        addBehaviour(10,new WanderBehaviour());
    }

    /**
     * @param otherActor the Actor that might perform an action.
     * @param direction  String representing the direction of the other Actor
     * @param map        current GameMap
     * @return list of actions
     */
    @Override
    public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
        ActionList actions = new ActionList();
        if (otherActor instanceof Pokemon && !otherActor.hasCapability(Element.FIRE)){
            actions.add(new AttackAction(this, direction));
        }
        // REQ 4 - catchAction
        else if (otherActor instanceof Player){
            if(otherActor.hasCapability(Status.GIVEABLE) && this.hasCapability(Status.FEEDABLE)){
                for(Item item: otherActor.getInventory()){
                    if(item instanceof Pokefruit){
                        actions.add(new FeedFruitAction(this, (Pokefruit) item, direction));
                    }
                }
            }

            //check condition for follow behaviour
            AffectionManager affectionManager = AffectionManager.getInstance();
            if(affectionManager.getAffectionPoint(this) >= 75){
                addBehaviour(9 , new FollowBehaviour(otherActor));
            }
        }
        //FIXME: allow other actor to attack this Charmander (excl. Player). Please check requirement! :)
        return actions;
    }

    /**
     * playTurn method for the Charmander that handle multi turn actions, and print the console menu
     *
     * @param actions    collection of possible Actions for this Actor
     * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction()
     * @param map        the map containing the Actor
     * @param display    the I/O object to which messages may be written
     * @return menu ( displays list of possible actions that can be done )
     */
    @Override
    public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
        //if pokemon is dead by day/night effect
        if(!this.isConscious()){
            map.removeActor(this);
        }
        // check condition for a special attack
        Location location = map.locationOf(this);
        if (location.getGround().hasCapability(Element.FIRE)){
            backupWeapons.addWeapon(new Ember());
            isEquipping = true;
        }
        else{
            isEquipping = false;
        }
        // call toggleWeapon to equip the special weapon
        toggleWeapon(isEquipping);
        for (Behaviour behaviour : behaviours.values()) {
            Action action = behaviour.getAction(this, map);
            if (action != null)
                return action;

        }
        // Otherwise, do nothing
        return new DoNothingAction();
    }

    /**
     * Creates and returns an intrinsic weapon.
     *
     * By default, a Charmander 'scratches' for 10 damage.
     *
     * @return a freshly-instantiated IntrinsicWeapon.
     */
    @Override
    protected IntrinsicWeapon getIntrinsicWeapon() {
        return new IntrinsicWeapon(10,"scratch");
    }

    /**
     * The day effect of Charmander.
     */
    @Override
    public void dayEffect() {
        if(!this.hasCapability(Status.IMMUNE)) {
            heal(CHARMANDER_HEAL);
        }
    }

    /**
     * The night effect of Charmander.
     */
    @Override
    public void nightEffect() {
        if(!this.hasCapability(Status.IMMUNE)) {
            hurt(CHARMANDER_HURT);
        }
    }



}
