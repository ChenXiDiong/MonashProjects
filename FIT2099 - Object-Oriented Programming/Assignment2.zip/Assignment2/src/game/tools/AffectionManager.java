package game.tools;

import edu.monash.fit2099.engine.actors.Actor;

import game.pokemon.Pokemon;
import java.util.HashMap;
import java.util.Map;

/**
 * Affection Manager
 * <p>
 * Created by:
 * @author Riordan D. Alfredo
 * Modified by:
 * @author Lab4Group5
 */
public class AffectionManager {

    /**
     * Singleton instance (the one and only for a whole game).
     */
    private static AffectionManager instance;
    /**
     * HINT: is it just for a Charmander?
     */
    private final Map<Pokemon, Integer> affectionPoints;

    /**
     * We assume there's only one trainer in this manager.
     * Think about how will you extend it.
     */
    private Actor trainer;

    private static final int MAX_AP_LEVEL=100;

    private static final int START_AP =0;

    /**
     * private singleton constructor
     */
    private AffectionManager() {
        this.affectionPoints = new HashMap<>();
    }

    /**
     * Access single instance publicly
     *
     * @return this instance
     */
    public static AffectionManager getInstance() {
        if (instance == null) {
            instance = new AffectionManager();
        }
        return instance;
    }

    /**
     * Add a trainer to this class's attribute. Assume there's only one trainer at a time.
     *
     * @param trainer the actor instance
     */
    public void registerTrainer(Actor trainer) {
        this.trainer = trainer;
    }

    /**
     * Add Pokemon to the collection. By default, it has 0 affection point. Ideally, you'll register all instantiated Pokemon
     *
     * @param pokemon the pokemon to be registered.
     */
    public void registerPokemon(Pokemon pokemon) {
        affectionPoints.put(pokemon,START_AP);
    }

    /**
     * Get the affection point by using the pokemon instance as the key.
     *
     * @param pokemon Pokemon instance
     * @return integer of affection point.
     */
    public int getAffectionPoint(Pokemon pokemon) {
        return affectionPoints.get(pokemon);
    }

    /**
     * Useful method to search a pokemon by using Actor instance.
     *
     * @param actor general actor instance
     * @return the Pokemon instance.
     */
    private Pokemon findPokemon(Actor actor) {
        for (Pokemon pokemon : affectionPoints.keySet()) {
            if (pokemon.equals(actor)) {
                return pokemon;
            }
        }
        return null;
    }

    /**
     * Increase the affection. Work on both cases when there's a Pokemon,
     * or when it doesn't exist in the collection.
     *
     * @param actor Actor instance, but we expect a Pokemon here.
     * @param point positive affection modifier
     * @return custom message to be printed by Display instance later.
     */

    public String increaseAffection(Actor actor, int point) {
        String message ="";
        // when there's a Pokemon :
        Pokemon pokemon = findPokemon(actor);
        if(pokemon != null){
            int old_ap = getAffectionPoint(pokemon);
            if (old_ap+point < MAX_AP_LEVEL){
                affectionPoints.replace(pokemon,old_ap+point);
                message = pokemon + " increases " + point;
            }
            else{
                affectionPoints.replace(pokemon,MAX_AP_LEVEL);
                message = pokemon +" reaches max AP level.";
            }
        }
        // when it
        //
        //
        // doesn't exist in the collection
        else{
            message = "The Pokemon doesn't exist in the collection";
        }
        return message;
    }

    /**
     * Decrease the affection level. Work on both cases when it is
     *
     * @param actor Actor instance, but we expect a Pokemon here.
     * @param point positive affection modifier (to be subtracted later)
     * @return custom message to be printed by Display instance later.
     */
    public String decreaseAffection(Actor actor, int point) {
        String message ="";
        // when there's a Pokemon
        Pokemon pokemon = findPokemon(actor);
        if(pokemon != null){
            int old_ap = getAffectionPoint(pokemon);
            affectionPoints.replace(pokemon,old_ap-point);
            message = actor + " decreases " + point;
        }
        // when it doesn't exist in the collection
        else{
            message = "The Pokemon doesn't exist in the collection";
        }
        return message;
    }

}
