package game.weapons;


import edu.monash.fit2099.engine.weapons.WeaponItem;

/**
 * Bubble ( weapon ) class
 *
 * Bubble is a Weapon, therefore it is an extension of weapon Item.
 *
 * Created by:
 * @author Lab4Group5
 */
public class Bubble extends WeaponItem {
  // variables declaration :

  /**
   * The name of this weapon is :
   */
  private final static String BUBBLE_NAME = "bubble";

  /**
   * The display char of this weapon :
   */
  private final static char BUBBLE_DISPLAY_CHAR = 'B';

  /**
   * The amount of damage that this weapon deals :
   */
  private final static int BUBBLE_DAMAGE = 25;

  /**
   * Action verb when attacking using this weapon :
   */
  private final static String BUBBLE_VERB = "burbles";

  /**
   * The hit rate of this weapon :
   */
  private final static int BUBBLE_HIT_RATE = 80;

  /**
   * Constructor.
   */
  public Bubble(){
  // super method
    super(BUBBLE_NAME,BUBBLE_DISPLAY_CHAR,BUBBLE_DAMAGE,BUBBLE_VERB,BUBBLE_HIT_RATE);
  }
}