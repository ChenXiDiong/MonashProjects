package game.weapons;

import edu.monash.fit2099.engine.actors.Actor;

import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.actions.AttackAction;
import java.util.ArrayList;

/**
 * Created by: provided by the teaching team
 * @author Riordan D. Alfredo
 *
 * Modified by:
 * @author Lab4Group5
 *
 * TODO: Use this class to store Pokemon's weapons (special attack) permanently.
 * If a Pokemon needs to use a weapon, put it into that Pokemon's inventory.
 * @see Actor #getWeapon() method.
 * @see AttackAction uses getWeapon() in the execute() method.
 */
public class BackupWeapons {

    /**
     * The list of WeaponItems.
     */
    private final ArrayList<WeaponItem> weaponList;

    /**
     * Constructor
     */
    public BackupWeapons( ){
        weaponList = new ArrayList<>();
    }

    /**
     * Adds a WeaponItem to the weaponList
     *
     * @param weaponItem the WeaponItem to be added.
     */
    public void addWeapon(WeaponItem weaponItem){
        weaponList.add(weaponItem);
    }

    /**
     * Gets a WeaponItem from the weaponList.
     *
     * @return the WeaponItem found.
     */
    public WeaponItem getWeapon(){
        return weaponList.get(weaponList.size()-1);
    }


}
