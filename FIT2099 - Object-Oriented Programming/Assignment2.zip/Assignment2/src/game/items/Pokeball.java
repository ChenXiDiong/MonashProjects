package game.items;


import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import game.enums.Status;
import game.actions.SummonAction;
import game.trading.Tradable;
import game.pokemon.Pokemon;

/**
 * The Pokeball Item.
 */
public class Pokeball extends Item implements Tradable {

  /**
   * The Pokemon within the Pokeball.
   */
  private Pokemon capturedPokemon;
  /**
   * The name of Pokeball.
   */
  private static final String POKEBALL_NAME = "Pokeball";
  /**
   * The display character of Pokeball.
   */
  private static final char POKEBALL_DISPLAY_CHAR = '0';
  /**
   * Indication of whether the Pokeball is portable.
   */
  private static final boolean POKEBALL_IS_PORTABLE = true;

  /**
   * Constructor
   *
   * @param capturedPokemon the Pokemon to be stored inside the Pokeball.
   */
  public Pokeball(Pokemon capturedPokemon) {
    super(POKEBALL_NAME, POKEBALL_DISPLAY_CHAR, POKEBALL_IS_PORTABLE);
    this.capturedPokemon = capturedPokemon;
    this.capturedPokemon.addCapability(Status.IMMUNE);
    this.addAction(new SummonAction(this, capturedPokemon));
  }


  /**
   * A description of Pokeball containing Charmander being traded for.
   *
   * @param by the actor doing the trade.
   * @return The result of the item being traded.
   */
  @Override
  public String trade(Actor by) {
    //a Charmander (to be packed inside the Pokeball).
    //Pokeball with Charmander is added to player's inventory.
    by.addItemToInventory(this);
    // initialize the AP
    String result = this.capturedPokemon+" (with pokeball) is added to "+ by+" inventory";
    return result;
  }

  /**
   * A printable String displaying the current Pokemon inside the Pokeball.
   *
   * @return the details of the captured Pokemon.
   */
  @Override
  public String toString(){
    return this.capturedPokemon.toString();
  }

}
