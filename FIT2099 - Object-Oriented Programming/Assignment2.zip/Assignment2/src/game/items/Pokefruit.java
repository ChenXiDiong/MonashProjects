package game.items;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import game.enums.Element;
import game.enums.Status;
import game.trading.Tradable;

/**
 * The Pokefruit Item.
 */
public class Pokefruit extends Item implements Tradable {

  /**
   * The name of Pokefruit.
   */
  private static final String POKEFRUIT_NAME = "Pokefruit";
  /**
   * The display character of Pokefruit.
   */
  private static final char POKEFRUIT_DISPLAY_CHAR = 'f';
  /**
   * Indication of whether the Pokefruit is portable.
   */
  private static final boolean POKEFRUIT_IS_PORTABLE = true;

  /***
   * Constructor for Pokefruit.
   *
   * @param element the element of the Pokefruit.
   */
  public Pokefruit(Element element) {
    super(POKEFRUIT_NAME, POKEFRUIT_DISPLAY_CHAR, POKEFRUIT_IS_PORTABLE);
    this.addCapability(element);
    this.addCapability(Status.GIVEABLE);
  }

  /**
   * A printable String of the Pokefruit.
   *
   * @return the description of the Pokefruit.
   */
  @Override
  public String toString() {
    return this.findCapabilitiesByType(Element.class).toString() + " Fruit";
  }

  /**
   * A description of the Pokefruit being traded for.
   *
   * @param by the actor doing the trade.
   * @return The result of the item being traded.
   */
  @Override
  public String trade(Actor by) {
    by.addItemToInventory(this);
    return this+ " is added to the inventory";
  }
}
