package game.items;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;

/**
 * The Candy Item.
 */
public class Candy extends Item {

  /**
   * The name of Candy.
   */
  private static final String CANDY_NAME = "Candy";
  /**
   * The display character of the Candy.
   */
  private static final char CANDY_DISPLAY_CHAR = '*';
  /**
   * Indication of whether the Candy is portable.
   */
  private static final boolean CANDY_IS_PORTABLE = true;


  /***
   * Constructor method for candy.
   */
  public Candy() {
    super(CANDY_NAME, CANDY_DISPLAY_CHAR, CANDY_IS_PORTABLE);


  }

  /**
   * Printable String of Candy.
   *
   * @return the description of Candy.
   */
  @Override
  public String toString(){
    return CANDY_NAME;
  }
}
