package game.behaviours;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.GameMap;
import game.actions.AttackAction;
import game.enums.Element;
import game.pokemon.Pokemon;
import game.tools.ElementsHelper;

/**
 * The behaviour of attacking an Actor.
 * Created by:
 * @author Riordan D. Alfredo
 * Modified by:
 * @author Lab4Group5
 */
public class AttackBehaviour implements Behaviour {

    /**
     * Gives an Attack Action to the Actor with the Attack Behaviour.
     *
     * @param actor the Actor acting
     * @param map the GameMap containing the Actor
     * @return an Attack Action to be performed.
     */
    @Override
    public Action getAction(Actor actor, GameMap map) {
        // FIXME: fakeOtherActor is a completely new instance that doesn't exist anywhere in the map! Check the requirement.
        Actor target;
        // check surrounding
        for(Exit exit : map.locationOf(actor).getExits()){
            // if there's an opponent
            if(exit.getDestination().getActor() instanceof Pokemon){
                target = exit.getDestination().getActor();
                // check if the element is different
                if(!ElementsHelper.hasAnySimilarElements(actor, target.findCapabilitiesByType(
                    Element.class))){
                    // different element - can initialize the attack
                    return new AttackAction(target, exit.getName());
                }
            }
        }
        return null;

    }
}
