package game.enums;

/**
 * Use this enum class to give `buff` or `debuff`.
 * It is also useful to give a `state` to abilities or actions that can be attached-detached.
 */
public enum Status {
    /**
     *  Status to identify that an object is immune to any attack.
     */
    IMMUNE,
    /**
     * Status to be considered hostile towards enemy (e.g., to be attacked by enemy)
     */
    HOSTILE,
    /**
     * Status to identify that an object is capturable.
     */
    CATCHABLE,
    /**
     * Status to identify that an object is feedable.
     */
    FEEDABLE,
    /**
     * Status to identify that an object is givable.
     */
    GIVEABLE
}
