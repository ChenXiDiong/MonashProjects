package game.time;

/**
 * Enumeration of the time period inside the game ( day and night )
 *
 * Sets time period ( either day or night ) in the Pokemon game World
 *
 * Created by:
 * @author Lab4Group5
 */
public enum TimePeriod {
    /**
     * The first time period is Day time
     */
    DAY,

    /**
     * Second one is Night time
     */
    NIGHT
}
