package game.time;

/**
 * The TimePerception interface.
 * Created by:Provided by the teaching team in the assignment starter file
 *
 * @author Riordan D. Alfredo
 * Modified by:
 * @author Lab4Group5
 */
public interface TimePerception {
    /**
     * The effect to happen during the day.
     */
    void dayEffect();

    /**
     * The effect to happen during the night.
     */
    void nightEffect();

    /**
     * a default interface method that register current instance to the Singleton manager.
     * It allows corresponding class uses to be affected by global reset
     * TODO: Use this method at the constructor of the concrete class that implements it (`this` instance).
     *       For example:
     *       Simple(){
     *          // other stuff for constructors.
     *          this.registerInstance()  // add this instance to the relevant manager.
     *       }
     */
    default void registerInstance(){
        TimePerceptionManager.getInstance().append(this);
    }
}
